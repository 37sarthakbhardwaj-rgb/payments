import React from 'react';
import { X, ShieldAlert, AlertTriangle, Smartphone, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { RiskBadge } from './RiskBadge';

interface Props {
  transaction: any | null;
  onClose: () => void;
}

export const ExplanationModal: React.FC<Props> = ({ transaction, onClose }) => {
  if (!transaction) return null;

  const factors = transaction.risk_factors || transaction.feature_breakdown || [];
  const rules = transaction.rules_triggered || [];
  const preventionSteps = transaction.prevention_steps || [];
  const dev = transaction.device_signals || {};

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-navy-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center space-x-3">
              <h2 className="text-xl font-bold font-mono text-white tracking-tight">
                {transaction.id || transaction.transaction_id}
              </h2>
              <RiskBadge tier={transaction.risk_tier} size="md" />
            </div>
            <p className="mt-1 text-xs text-slate-400">
              Scam Category:{' '}
              <span className="font-mono text-cyan-400 font-semibold">
                {transaction.scam_category || 'NORMAL'}
              </span>
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Transaction Overview Grid */}
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 bg-navy-950/60 p-3.5 rounded-xl border border-slate-800/80 text-xs font-mono">
          <div>
            <span className="text-slate-500 block text-[10px] uppercase">Amount</span>
            <span className="text-emerald-400 font-bold text-sm">
              ₹{transaction.amount?.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase">Channel</span>
            <span className="text-slate-200 font-semibold">{transaction.channel}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase">Payee VPA</span>
            <span className="text-cyan-300 truncate block">{transaction.payee_vpa}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase">Payee Name</span>
            <span className="text-slate-300 truncate block">{transaction.payee_name}</span>
          </div>
        </div>

        {/* AI Explanation Summary */}
        <div className="mt-4 p-4 rounded-xl bg-gradient-to-r from-red-950/20 via-navy-900 to-navy-950 border border-red-500/30">
          <div className="flex items-start space-x-3">
            <ShieldAlert className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-white">AI Detection & Explainability Summary</h4>
              <p className="mt-1 text-xs leading-relaxed text-slate-300">
                {transaction.explanation_summary || 'No explanation summary available.'}
              </p>
              <div className="mt-2 text-xs font-mono">
                <span className="text-slate-400">Action Recommended: </span>
                <span className="font-bold text-red-400">{transaction.recommended_action}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Multi-Factor Attribution Breakdown */}
        {factors.length > 0 && (
          <div className="mt-5">
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
              Explainability Factor Attribution (Risk Contributors)
            </h4>
            <div className="space-y-2">
              {factors.map((f: any, idx: number) => (
                <div
                  key={idx}
                  className="p-3 rounded-lg bg-navy-950 border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div className="pr-4">
                    <span className="font-semibold text-slate-200 block">{f.factor_name}</span>
                    <span className="text-slate-400 text-[11px]">{f.description}</span>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <span
                      className={`font-mono font-bold ${
                        f.impact_score > 0 ? 'text-red-400' : 'text-emerald-400'
                      }`}
                    >
                      {f.impact_score > 0 ? `+${f.impact_score}` : f.impact_score}%
                    </span>
                    <span className="block text-[10px] text-slate-500 font-mono">{f.severity}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Triggered Expert Rules */}
        {rules.length > 0 && (
          <div className="mt-5">
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
              Triggered Expert Security Rules ({rules.length})
            </h4>
            <div className="space-y-2">
              {rules.map((rule: any, idx: number) => (
                <div
                  key={idx}
                  className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-amber-400 font-semibold">{rule.rule_code}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">
                      {rule.severity}
                    </span>
                  </div>
                  <p className="mt-1 font-medium text-slate-200">{rule.title}</p>
                  <p className="mt-0.5 text-slate-400 text-[11px] leading-relaxed">{rule.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Prevention Advice */}
        {preventionSteps.length > 0 && (
          <div className="mt-5 p-4 rounded-xl bg-cyan-950/20 border border-cyan-500/30">
            <h4 className="text-xs font-semibold text-cyan-300 flex items-center space-x-1.5 mb-2">
              <CheckCircle2 className="h-4 w-4 text-cyan-400" />
              <span>Recommended Immediate Actions for User</span>
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-300">
              {preventionSteps.map((step: string, idx: number) => (
                <li key={idx} className="flex items-start space-x-2">
                  <span className="text-cyan-400 font-bold">•</span>
                  <span>{step}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Device Signals Captured */}
        {Object.keys(dev).length > 0 && (
          <div className="mt-5 pt-4 border-t border-slate-800">
            <h4 className="text-[11px] font-mono text-slate-500 uppercase tracking-wider mb-2">
              Device Integrity & Telemetry Signals
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] font-mono">
              <div className="p-2 rounded bg-navy-950 border border-slate-800">
                <span className="text-slate-500 block">Screen Sharing:</span>
                <span className={dev.screen_sharing_active ? 'text-red-400 font-bold' : 'text-slate-300'}>
                  {dev.screen_sharing_active ? 'ACTIVE (DETECTED)' : 'Inactive'}
                </span>
              </div>
              <div className="p-2 rounded bg-navy-950 border border-slate-800">
                <span className="text-slate-500 block">Remote App:</span>
                <span className={dev.remote_access_app_detected ? 'text-red-400 font-bold' : 'text-slate-300'}>
                  {dev.remote_access_app_detected ? 'YES (AnyDesk/TeamViewer)' : 'None'}
                </span>
              </div>
              <div className="p-2 rounded bg-navy-950 border border-slate-800">
                <span className="text-slate-500 block">Call In Progress:</span>
                <span className={dev.call_in_progress ? 'text-amber-400 font-bold' : 'text-slate-300'}>
                  {dev.call_in_progress ? 'YES' : 'No'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Close Button */}
        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition-colors"
          >
            Close Investigation
          </button>
        </div>
      </div>
    </div>
  );
};

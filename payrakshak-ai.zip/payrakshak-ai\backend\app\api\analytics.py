from typing import List, Dict, Any
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.core.database import get_db
from app.models.db_models import TransactionRecord, ModelEvaluationLog
from app.models.schemas import OverviewStats, FraudCategoryStat, RiskLevelStat, ActivityTimePoint
from app.services.ml_engine import MLEngine

router = APIRouter(prefix="/analytics", tags=["Analytics & Reporting"])

SCAM_NAME_MAP = {
    "FAKE_COLLECT_REFUND_SCAM": "Collect Request / OLX Refund Scams",
    "QR_CODE_PAYMENT_SCAM": "Malicious QR Code Deception",
    "REMOTE_ACCESS_APP_SCAM": "Remote Desktop / AnyDesk Impersonation",
    "FAKE_INVESTMENT_JOB_SCAM": "Telegram Tasks & High-Yield Schemes",
    "MULE_ACCOUNT_PATTERNS": "High-Velocity Money Mule Accounts",
    "PHISHING_PAYMENT_LINK": "Phishing Links & Rogue Portals",
    "FAKE_KYC_ACCOUNT_BLOCK_THREAT": "Fake KYC & Electricity Cutoff Threats",
    "NORMAL": "Legitimate Consumer & Merchant Payments"
}

@router.get("/overview", response_model=OverviewStats)
def get_overview_statistics(db: Session = Depends(get_db)):
    total = db.query(TransactionRecord).count()
    flagged = db.query(TransactionRecord).filter(TransactionRecord.is_flagged == True).count()
    high_critical = db.query(TransactionRecord).filter(
        TransactionRecord.risk_tier.in_(["HIGH", "CRITICAL"])
    ).count()
    safe = total - flagged
    fraud_share = round((flagged / total * 100.0), 2) if total > 0 else 0.0

    # Get offline test dataset evaluation metrics
    eval_log = db.query(ModelEvaluationLog).order_by(ModelEvaluationLog.id.desc()).first()
    if not eval_log:
        _, metrics = MLEngine.get_or_load_model()
    else:
        metrics = {
            "fraud_detection_rate": eval_log.fraud_detection_rate,
            "false_positive_rate": eval_log.false_positive_rate,
            "accuracy": eval_log.accuracy,
            "precision": eval_log.precision,
            "f1_score": eval_log.f1_score,
            "roc_auc": eval_log.roc_auc,
            "test_samples": eval_log.test_samples
        }

    return OverviewStats(
        total_transactions_analyzed=total,
        flagged_suspicious_count=flagged,
        high_critical_risk_count=high_critical,
        safe_transactions_count=safe,
        fraud_share_percentage=fraud_share,
        offline_fraud_detection_rate=round(metrics["fraud_detection_rate"] * 100.0, 2),
        offline_false_positive_rate=round(metrics["false_positive_rate"] * 100.0, 2),
        offline_accuracy=round(metrics["accuracy"] * 100.0, 2),
        offline_precision=round(metrics["precision"] * 100.0, 2),
        offline_f1_score=round(metrics["f1_score"] * 100.0, 2),
        offline_roc_auc=round(metrics["roc_auc"], 4),
        offline_test_samples=metrics.get("test_samples", 1200),
        live_vs_offline_explanation=(
            "Offline Model Evaluation Metrics are benchmarked against an independent held-out test split "
            f"of {metrics.get('test_samples', 1200):,} pre-labeled synthetic transactions to assess generalized recall "
            "and false-alarm control. In contrast, Live Demo Statistics reflect runtime operational totals "
            "from this application's transactional database, showing real-time scam interception."
        )
    )

@router.get("/categories", response_model=List[FraudCategoryStat])
def get_fraud_category_distribution(db: Session = Depends(get_db)):
    results = db.query(
        TransactionRecord.scam_category,
        func.count(TransactionRecord.id).label("count"),
        func.avg(TransactionRecord.risk_score).label("avg_risk")
    ).group_by(TransactionRecord.scam_category).all()

    total_records = db.query(TransactionRecord).count() or 1
    categories_data = []

    for cat, count, avg_risk in results:
        category_name = cat or "NORMAL"
        pct = round((count / total_records) * 100.0, 1)
        categories_data.append(FraudCategoryStat(
            category=category_name,
            count=count,
            percentage=pct,
            avg_risk_score=round(float(avg_risk), 1) if avg_risk else 0.0,
            sample_scam_name=SCAM_NAME_MAP.get(category_name, category_name)
        ))

    # Sort so highest fraud count comes first (with NORMAL at the end)
    categories_data.sort(key=lambda x: (x.category == "NORMAL", -x.count))
    return categories_data

@router.get("/activity", response_model=List[ActivityTimePoint])
def get_transaction_activity(db: Session = Depends(get_db)):
    # Group transactions by day or 6-hour buckets
    txns = db.query(TransactionRecord.timestamp, TransactionRecord.is_flagged).order_by(
        TransactionRecord.timestamp.asc()
    ).all()

    # Bucket into 7 chronological intervals
    if not txns:
        return []

    # Format into 7 timeline intervals
    interval_data: Dict[str, Dict[str, int]] = {}
    for t, flagged in txns:
        if t:
            day_str = t.strftime("%b %d")
        else:
            day_str = "Recent"

        if day_str not in interval_data:
            interval_data[day_str] = {"total": 0, "legit": 0, "flagged": 0}

        interval_data[day_str]["total"] += 1
        if flagged:
            interval_data[day_str]["flagged"] += 1
        else:
            interval_data[day_str]["legit"] += 1

    return [
        ActivityTimePoint(
            time_label=day,
            total_volume=counts["total"],
            legitimate_volume=counts["legit"],
            flagged_volume=counts["flagged"]
        )
        for day, counts in list(interval_data.items())[-7:]  # Last 7 distinct days
    ]

@router.get("/risk-distribution", response_model=List[RiskLevelStat])
def get_risk_distribution(db: Session = Depends(get_db)):
    tiers = ["SAFE", "LOW", "MODERATE", "HIGH", "CRITICAL"]
    color_map = {
        "SAFE": "#10B981",
        "LOW": "#34D399",
        "MODERATE": "#F59E0B",
        "HIGH": "#F97316",
        "CRITICAL": "#EF4444"
    }
    
    total = db.query(TransactionRecord).count() or 1
    stats = []

    for tier in tiers:
        count = db.query(TransactionRecord).filter(TransactionRecord.risk_tier == tier).count()
        pct = round((count / total) * 100.0, 1)
        stats.append(RiskLevelStat(
            tier=tier,
            count=count,
            percentage=pct,
            color=color_map[tier]
        ))

    return stats

@router.get("/ml-insights")
def get_ml_model_insights(db: Session = Depends(get_db)):
    eval_log = db.query(ModelEvaluationLog).order_by(ModelEvaluationLog.id.desc()).first()
    if not eval_log:
        _, metrics = MLEngine.get_or_load_model()
    else:
        metrics = {
            "model_name": eval_log.model_name,
            "train_samples": eval_log.train_samples,
            "test_samples": eval_log.test_samples,
            "accuracy": eval_log.accuracy,
            "precision": eval_log.precision,
            "recall": eval_log.recall,
            "f1_score": eval_log.f1_score,
            "roc_auc": eval_log.roc_auc,
            "fraud_detection_rate": eval_log.fraud_detection_rate,
            "false_positive_rate": eval_log.false_positive_rate,
            "confusion_matrix": eval_log.confusion_matrix,
            "feature_importances": eval_log.feature_importances
        }

    return metrics

from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.core.database import get_db
from app.models.db_models import ThreatIntelligence
from app.models.schemas import ThreatIntelResponse, ThreatIntelCreate

router = APIRouter(prefix="/threat-intel", tags=["Threat Intelligence"])

@router.get("/list", response_model=List[ThreatIntelResponse])
def get_threat_intel_list(
    indicator_type: Optional[str] = Query(None, description="VPA, URL, PHONE, APK"),
    search: Optional[str] = None,
    limit: int = Query(50, le=100),
    db: Session = Depends(get_db)
):
    query = db.query(ThreatIntelligence).filter(ThreatIntelligence.is_active == True)
    if indicator_type:
        query = query.filter(ThreatIntelligence.indicator_type == indicator_type.upper())
    if search:
        pattern = f"%{search}%"
        query = query.filter(
            (ThreatIntelligence.indicator_value.ilike(pattern)) |
            (ThreatIntelligence.description.ilike(pattern)) |
            (ThreatIntelligence.threat_category.ilike(pattern))
        )

    records = query.order_by(desc(ThreatIntelligence.reported_date)).limit(limit).all()

    return [
        ThreatIntelResponse(
            id=r.id,
            indicator_type=r.indicator_type,
            indicator_value=r.indicator_value,
            threat_category=r.threat_category,
            risk_level=r.risk_level,
            description=r.description,
            source=r.source,
            is_active=r.is_active,
            reported_date=r.reported_date.isoformat() if r.reported_date else ""
        )
        for r in records
    ]

@router.post("/add", response_model=ThreatIntelResponse)
def add_threat_indicator(data: ThreatIntelCreate, db: Session = Depends(get_db)):
    ti = ThreatIntelligence(
        indicator_type=data.indicator_type.upper(),
        indicator_value=data.indicator_value.lower().strip(),
        threat_category=data.threat_category,
        risk_level=data.risk_level,
        description=data.description,
        source=data.source
    )
    db.add(ti)
    db.commit()
    db.refresh(ti)

    return ThreatIntelResponse(
        id=ti.id,
        indicator_type=ti.indicator_type,
        indicator_value=ti.indicator_value,
        threat_category=ti.threat_category,
        risk_level=ti.risk_level,
        description=ti.description,
        source=ti.source,
        is_active=ti.is_active,
        reported_date=ti.reported_date.isoformat()
    )

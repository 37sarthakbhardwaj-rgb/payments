Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   PayRakshak AI — Frontend Web Interface Starting" -ForegroundColor Cyan
Write-Host "   Target URL: http://localhost:5173" -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Cyan

Set-Location -Path "frontend"
npm run dev -- --host

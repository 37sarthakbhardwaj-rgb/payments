import React from 'react';
import {
  LayoutDashboard,
  ShieldCheck,
  MessageSquareWarning,
  Sparkles,
  Database,
  BarChart3,
  ExternalLink,
  PhoneCall,
  Activity
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, setCurrentTab }) => {
  const navItems = [
    {
      id: 'overview',
      label: 'Overview Dashboard',
      icon: LayoutDashboard,
      badge: 'Live',
    },
    {
      id: 'scanner',
      label: 'Transaction Scanner',
      icon: ShieldCheck,
      badge: 'AI Core',
    },
    {
      id: 'messages',
      label: 'Phishing & SMS Scanner',
      icon: MessageSquareWarning,
      badge: 'NLP',
    },
    {
      id: 'simulations',
      label: 'Creative Fraud Simulator',
      icon: Sparkles,
      badge: '7 Scams',
    },
    {
      id: 'threat-intel',
      label: 'Threat Intelligence Feed',
      icon: Database,
      badge: 'I4C',
    },
    {
      id: 'analytics',
      label: 'Model Analytics & ML',
      icon: BarChart3,
      badge: 'Metrics',
    },
  ];

  return (
    <aside className="w-64 flex-shrink-0 bg-navy-900 border-r border-slate-800/80 flex flex-col justify-between hidden md:flex">
      <div>
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-800/80 flex items-center space-x-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
            <ShieldCheck className="h-6 w-6 text-navy-950 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-extrabold text-base tracking-tight text-white">PayRakshak</span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                AI
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">CyberCup 6.0 · CCG-AI02</p>
          </div>
        </div>

        {/* Navigation Items */}
        <div className="p-3 space-y-1">
          <p className="px-3 pt-3 pb-1 text-[10px] font-mono uppercase tracking-wider text-slate-500">
            Security Control Plane
          </p>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500/15 to-blue-500/10 text-cyan-400 border border-cyan-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon className={`h-4 w-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                      isActive
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                        : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Cyber Helpline Widget */}
      <div className="p-4 border-t border-slate-800/80 m-3 rounded-xl bg-gradient-to-b from-navy-850 to-navy-950 border border-cyan-500/20">
        <div className="flex items-center justify-between">
          <span className="flex items-center space-x-1.5 text-xs font-semibold text-white">
            <PhoneCall className="h-3.5 w-3.5 text-cyan-400" />
            <span>Cyber Helpline</span>
          </span>
          <span className="inline-flex h-2 w-2 rounded-full bg-emerald-400 animate-ping"></span>
        </div>
        <p className="mt-1 text-[11px] text-slate-400">Toll-free National Cyber Fraud Helpline (I4C)</p>
        <div className="mt-2 flex items-center justify-between bg-navy-900 px-2.5 py-1.5 rounded-lg border border-slate-800">
          <span className="text-xs font-mono font-bold text-cyan-300">Dial 1930</span>
          <span className="text-[10px] text-slate-500 font-mono">24x7 Active</span>
        </div>
      </div>
    </aside>
  );
};

import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app

@pytest.mark.anyio
async def test_health_endpoint():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "PayRakshak AI" in data["service"]

@pytest.mark.anyio
async def test_scan_transaction_api():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        payload = {
            "sender_vpa": "rahul@okaxis",
            "payee_vpa": "olx.buyer.pay@ybl",
            "payee_name": "OLX Buyer Verification",
            "amount": 12000.0,
            "channel": "COLLECT_REQUEST",
            "note": "Enter UPI PIN to receive money",
            "payee_account_age_days": 3,
            "payee_velocity_1h": 20,
            "device_signals": {
                "remote_access_app_detected": False,
                "screen_sharing_active": False,
                "call_in_progress": True,
                "is_new_device": False,
                "is_rooted_or_jailbroken": False,
                "ip_vpn_or_proxy": False,
                "location_mismatch": False
            }
        }
        response = await client.post("/api/v1/transactions/scan", json=payload)
        assert response.status_code == 200
        data = response.json()
        assert data["is_flagged"] is True
        assert data["risk_tier"] in ["HIGH", "CRITICAL"]
        assert "COLLECT" in data["scam_category"]

@pytest.mark.anyio
async def test_scan_message_api():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        payload = {
            "raw_text": "Dear SBI Customer, your account is suspended due to pending KYC. Click http://bit.ly/sbi-pan-upd immediately to restore services.",
            "channel_type": "SMS"
        }
        response = await client.post("/api/v1/messages/scan", json=payload)
        assert response.status_code == 200
        data = response.json()
        assert data["is_malicious"] is True
        assert data["risk_score"] > 50.0
        assert len(data["extracted_entities"]["urls"]) > 0

@pytest.mark.anyio
async def test_analytics_overview_api():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get("/api/v1/analytics/overview")
        assert response.status_code == 200
        data = response.json()
        assert "offline_fraud_detection_rate" in data
        assert "offline_false_positive_rate" in data
        assert "live_vs_offline_explanation" in data

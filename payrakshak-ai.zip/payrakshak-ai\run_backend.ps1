Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   PayRakshak AI — Backend Service Starting" -ForegroundColor Cyan
Write-Host "   Tagline: Detect the scam. Explain the risk. Protect the payment." -ForegroundColor Gray
Write-Host "==========================================================" -ForegroundColor Cyan

$env:PYTHONPATH = "backend"
.\venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload

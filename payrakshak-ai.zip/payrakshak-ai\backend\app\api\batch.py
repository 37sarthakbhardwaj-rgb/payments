from typing import Dict, Any
from fastapi import APIRouter, Query, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.services.ml_engine import MLEngine
from app.services.synthetic_data import generate_synthetic_transactions
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score

router = APIRouter(prefix="/batch", tags=["Batch Evaluation & Testing"])

@router.post("/evaluate-synthetic-batch")
def evaluate_synthetic_batch(
    sample_size: int = Query(500, ge=100, le=2000),
    db: Session = Depends(get_db)
):
    """
    Generates a live synthetic test batch, runs both ML and rule heuristics,
    and returns immediate confusion matrix and performance statistics.
    """
    df = generate_synthetic_transactions(n_samples=sample_size)
    clf, _ = MLEngine.get_or_load_model()

    X = MLEngine.extract_features_from_df(df)
    y_true = df["is_fraud"].values

    y_pred = clf.predict(X)
    y_proba = clf.predict_proba(X)[:, 1]

    acc = float(accuracy_score(y_true, y_pred))
    prec = float(precision_score(y_true, y_pred, zero_division=0))
    rec = float(recall_score(y_true, y_pred, zero_division=0))
    f1 = float(f1_score(y_true, y_pred, zero_division=0))

    cm = confusion_matrix(y_true, y_pred).tolist()
    tn, fp, fn, tp = cm[0][0], cm[0][1], cm[1][0], cm[1][1]

    fraud_detection_rate = float(tp / (tp + fn)) if (tp + fn) > 0 else 0.0
    false_positive_rate = float(fp / (fp + tn)) if (fp + tn) > 0 else 0.0

    return {
        "status": "success",
        "sample_size": sample_size,
        "normal_samples_count": int(tn + fp),
        "fraud_samples_count": int(tp + fn),
        "accuracy": round(acc * 100.0, 2),
        "precision": round(prec * 100.0, 2),
        "recall": round(rec * 100.0, 2),
        "f1_score": round(f1 * 100.0, 2),
        "fraud_detection_rate": round(fraud_detection_rate * 100.0, 2),
        "false_positive_rate": round(false_positive_rate * 100.0, 2),
        "confusion_matrix": {
            "true_negatives": tn,
            "false_positives": fp,
            "false_negatives": fn,
            "true_positives": tp,
            "matrix": cm
        }
    }

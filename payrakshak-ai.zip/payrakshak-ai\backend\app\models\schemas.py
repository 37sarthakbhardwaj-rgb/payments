from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
import datetime

# Device & Behavioral Risk Signals
class DeviceRiskSignals(BaseModel):
    remote_access_app_detected: bool = Field(default=False, description="AnyDesk, TeamViewer, RustDesk, QuickSupport active")
    screen_sharing_active: bool = Field(default=False, description="OS screen capture/sharing is active")
    call_in_progress: bool = Field(default=False, description="Active voice call in progress during transaction")
    is_new_device: bool = Field(default=False, description="Device registered within last 48 hours")
    is_rooted_or_jailbroken: bool = Field(default=False, description="Device root/jailbreak integrity check failed")
    ip_vpn_or_proxy: bool = Field(default=False, description="Transaction originating via anonymizing proxy/VPN")
    location_mismatch: bool = Field(default=False, description="Current GPS coordinates diverge significantly from home base")

# Transaction Scan Request
class TransactionScanRequest(BaseModel):
    sender_vpa: str = Field(..., example="rahul.sharma@okaxis")
    payee_vpa: str = Field(..., example="refund.support.desk@ybl")
    payee_name: str = Field(..., example="Fast Customer Refund Portal")
    amount: float = Field(..., gt=0, example=4999.0)
    channel: str = Field(..., example="COLLECT_REQUEST")  # COLLECT_REQUEST, STATIC_QR, DYNAMIC_QR, INTENT, PAYMENT_LINK, NETBANKING
    note: Optional[str] = Field(default=None, example="Click approve to receive refund for your failed order")
    payee_account_age_days: Optional[int] = Field(default=3, description="Estimated age of beneficiary account in days")
    payee_velocity_1h: Optional[int] = Field(default=18, description="Transactions received by payee in the last 1 hour")
    device_signals: Optional[DeviceRiskSignals] = Field(default_factory=DeviceRiskSignals)

# Explainability Factor Item
class RiskFactor(BaseModel):
    factor_name: str
    impact_score: float  # -100 to +100
    severity: str        # CRITICAL, HIGH, MEDIUM, LOW, SAFE
    description: str

# Rule Hit Item
class RuleHit(BaseModel):
    rule_code: str
    category: str
    title: str
    severity: str
    description: str

# Transaction Scan Response
class TransactionScanResponse(BaseModel):
    transaction_id: str
    sender_vpa: str
    payee_vpa: str
    payee_name: str
    amount: float
    channel: str
    risk_score: float               # 0 to 100
    risk_tier: str                  # SAFE, LOW, MODERATE, HIGH, CRITICAL
    scam_category: Optional[str]    # One of the 7 creative scams or "NORMAL"
    is_flagged: bool
    recommended_action: str         # ALLOW, WARN_VERIFY, CHALLENGE_PIN, BLOCK_TRANSACTION
    explanation_summary: str
    risk_factors: List[RiskFactor]
    rules_triggered: List[RuleHit]
    prevention_steps: List[str]
    device_signals: Dict[str, Any]
    timestamp: str

# Message Scan Request & Response
class MessageScanRequest(BaseModel):
    raw_text: str = Field(..., example="Dear SBI Customer, your account is suspended due to pending KYC. Click http://bit.ly/sbi-pan-update to update PAN or electricity will be cut off.")
    channel_type: Optional[str] = Field(default="SMS")

class ExtractedEntities(BaseModel):
    urls: List[str]
    phones: List[str]
    vpas: List[str]
    apks: List[str]
    suspicious_phrases: List[str]

class MessageScanResponse(BaseModel):
    scan_id: str
    raw_text: str
    channel_type: str
    risk_score: float
    risk_tier: str
    is_malicious: bool
    detected_category: str
    extracted_entities: ExtractedEntities
    explanation: str
    recommended_action: str
    cyber_cell_advisory: str
    created_at: str

# Threat Intel Schemas
class ThreatIntelCreate(BaseModel):
    indicator_type: str
    indicator_value: str
    threat_category: str
    risk_level: str = "CRITICAL"
    description: str
    source: str = "I4C / 1930 Cyber Cell"

class ThreatIntelResponse(BaseModel):
    id: int
    indicator_type: str
    indicator_value: str
    threat_category: str
    risk_level: str
    description: str
    source: str
    is_active: bool
    reported_date: str

# Analytics Schemas
class OverviewStats(BaseModel):
    total_transactions_analyzed: int
    flagged_suspicious_count: int
    high_critical_risk_count: int
    safe_transactions_count: int
    fraud_share_percentage: float
    # Offline ML Test Dataset Metrics
    offline_fraud_detection_rate: float  # e.g., 96.8%
    offline_false_positive_rate: float   # e.g., 1.4%
    offline_accuracy: float
    offline_precision: float
    offline_f1_score: float
    offline_roc_auc: float
    offline_test_samples: int
    live_vs_offline_explanation: str

class FraudCategoryStat(BaseModel):
    category: str
    count: int
    percentage: float
    avg_risk_score: float
    sample_scam_name: str

class RiskLevelStat(BaseModel):
    tier: str
    count: int
    percentage: float
    color: str

class ActivityTimePoint(BaseModel):
    time_label: str
    total_volume: int
    legitimate_volume: int
    flagged_volume: int

# Scenario Definition
class ScenarioItem(BaseModel):
    id: str
    title: str
    subtitle: str
    scam_category: str
    icon_name: str
    sample_request: TransactionScanRequest
    context_story: str
    modus_operandi: str
    what_would_happen_without_ai: str

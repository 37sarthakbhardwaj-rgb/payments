from typing import List
from fastapi import APIRouter
from app.models.schemas import ScenarioItem, TransactionScanRequest, DeviceRiskSignals

router = APIRouter(prefix="/scenarios", tags=["Fraud Scenarios"])

PRESET_SCENARIOS: List[ScenarioItem] = [
    ScenarioItem(
        id="scen-collect-refund",
        title="OLX 'Approve to Receive' Collect Scam",
        subtitle="UPI PIN Inversion Deception",
        scam_category="FAKE_COLLECT_REFUND_SCAM",
        icon_name="ArrowDownLeft",
        sample_request=TransactionScanRequest(
            sender_vpa="priya.sharma@okhdfcbank",
            payee_vpa="olx.buyer.pay@ybl",
            payee_name="OLX Buyer Verification Desk",
            amount=15000.0,
            channel="COLLECT_REQUEST",
            note="Approve collect request and enter UPI PIN to receive money for your sofa",
            payee_account_age_days=3,
            payee_velocity_1h=19,
            device_signals=DeviceRiskSignals(
                call_in_progress=True,
                is_new_device=False
            )
        ),
        context_story="Victim listed a sofa on OLX. Scammer posing as an interested buyer claims they are sending payment via UPI, but actually initiates a Collect Request asking the seller to enter their UPI PIN.",
        modus_operandi="Exploits victim's misunderstanding that receiving money on UPI requires PIN authorization. Approving debits ₹15,000 from victim's account.",
        what_would_happen_without_ai="Victim approves the prompt, enters PIN, and loses ₹15,000 instantly without recourse."
    ),
    ScenarioItem(
        id="scen-remote-access",
        title="Fake Bank Customer Care + AnyDesk Screen Sharing",
        subtitle="Remote Access App Impersonation",
        scam_category="REMOTE_ACCESS_APP_SCAM",
        icon_name="MonitorSmartphone",
        sample_request=TransactionScanRequest(
            sender_vpa="vikram.patel@okaxis",
            payee_vpa="sbi.helpdesk.agent@ybl",
            payee_name="SBI Senior Care Executive",
            amount=1.0,
            channel="COLLECT_REQUEST",
            note="Pay Rs 1 test fee to reverse unauthorized debit on your card",
            payee_account_age_days=2,
            payee_velocity_1h=8,
            device_signals=DeviceRiskSignals(
                remote_access_app_detected=True,
                screen_sharing_active=True,
                call_in_progress=True,
                is_new_device=False
            )
        ),
        context_story="Victim Googled customer support for a failed ATM transaction and called a poisoned SEO number. Fraudster told victim to install AnyDesk and pay ₹1 to 'verify account'.",
        modus_operandi="While victim types UPI PIN and receives OTP on screen, fraudster watches live screen broadcast, captures MPIN, and drains secondary savings accounts.",
        what_would_happen_without_ai="Scammer records screen PIN entries and drains multiple lakhs from linked bank accounts."
    ),
    ScenarioItem(
        id="scen-qr-lottery",
        title="Mega Cashback / Lottery 'Scan to Win' QR Scam",
        subtitle="QR Code Payment Redirection",
        scam_category="QR_CODE_PAYMENT_SCAM",
        icon_name="QrCode",
        sample_request=TransactionScanRequest(
            sender_vpa="anita.rao@oksbi",
            payee_vpa="cashback.qr.claim@ybl",
            payee_name="Paytm Reward Scratch Card",
            amount=5000.0,
            channel="STATIC_QR",
            note="Scan QR code to claim your Rs 5,000 festival cashback reward",
            payee_account_age_days=5,
            payee_velocity_1h=14,
            device_signals=DeviceRiskSignals(
                call_in_progress=False,
                is_new_device=False
            )
        ),
        context_story="Victim received a WhatsApp message with a flashy scratch card banner saying 'Congratulations! You won ₹5,000 festival bonus. Scan this QR on PhonePe to deposit in bank.'",
        modus_operandi="QR codes only encode recipient VPAs and debit instructions. Victim thinks they are scanning to receive money, but scanning approves an outgoing payment of ₹5,000.",
        what_would_happen_without_ai="Victim scans QR expecting a deposit and immediately loses ₹5,000."
    ),
    ScenarioItem(
        id="scen-investment-telegram",
        title="Telegram Work-from-Home 'Task Rating' Scam",
        subtitle="Ponzi / Escalate Investment Trap",
        scam_category="FAKE_INVESTMENT_JOB_SCAM",
        icon_name="Briefcase",
        sample_request=TransactionScanRequest(
            sender_vpa="karan.singh@okaxis",
            payee_vpa="vip.telegram.tasks@paytm",
            payee_name="Global Merchant Task Deposit",
            amount=25000.0,
            channel="INTENT",
            note="VIP Level 3 Crypto Deposit for 40% Daily Return on hotel reviews",
            payee_account_age_days=6,
            payee_velocity_1h=38,
            device_signals=DeviceRiskSignals(
                call_in_progress=False,
                is_new_device=True
            )
        ),
        context_story="Victim was added to a Telegram group offering ₹5,000/day for liking YouTube videos. After paying ₹500 and receiving ₹700 back, victim is lured into 'pre-paying' ₹25,000 for VIP tasks.",
        modus_operandi="Pig-butchering task scam. Fake virtual dashboard shows artificial high profits, but real money goes to scam syndicate mule VPAs.",
        what_would_happen_without_ai="Funds are permanently lost to organized cybercrime syndicates."
    ),
    ScenarioItem(
        id="scen-mule-account",
        title="High-Velocity Transient Mule Beneficiary",
        subtitle="Layering & Rapid Fund Siphoning",
        scam_category="MULE_ACCOUNT_PATTERNS",
        icon_name="Users",
        sample_request=TransactionScanRequest(
            sender_vpa="deepak.kumar@okhdfcbank",
            payee_vpa="rajesh.transient77@paytm",
            payee_name="Quick Enterprise Solutions",
            amount=49000.0,
            channel="INTENT",
            note="Urgent invoice settlement",
            payee_account_age_days=2,
            payee_velocity_1h=45,
            device_signals=DeviceRiskSignals(
                call_in_progress=False,
                is_rooted_or_jailbroken=False
            )
        ),
        context_story="Victim is transferring ₹49,000 for an online freelance contract to an account created just 48 hours ago that has already processed 45 high-value transactions this hour.",
        modus_operandi="Transient mule account bought from low-income individuals used to siphon stolen funds within minutes before bank cyber cell freezes the account.",
        what_would_happen_without_ai="Within 90 seconds of receiving the money, mules cash it out at ATMs or convert it to crypto."
    ),
    ScenarioItem(
        id="scen-kyc-power",
        title="Electricity Disconnection Panic at 9:30 PM",
        subtitle="Coercive Threat & Malicious Gateway",
        scam_category="FAKE_KYC_ACCOUNT_BLOCK_THREAT",
        icon_name="ZapOff",
        sample_request=TransactionScanRequest(
            sender_vpa="sunita.devi@oksbi",
            payee_vpa="electricity.emergency.bill@okhdfcbank",
            payee_name="Emergency BESCOM Power Clearance",
            amount=1999.0,
            channel="PAYMENT_LINK",
            note="Urgent electricity reconnection fee to avoid blackout tonight",
            payee_account_age_days=4,
            payee_velocity_1h=22,
            device_signals=DeviceRiskSignals(
                call_in_progress=True,
                is_new_device=False
            )
        ),
        context_story="Victim received an alarming SMS at 8:45 PM: 'Your electricity will be disconnected at 9:30 PM due to unpaid bill. Click link or pay officer immediately.'",
        modus_operandi="Uses high urgency fear of power cut to make victim skip standard verification and rush payment to an untrusted VPA.",
        what_would_happen_without_ai="Victim pays under duress and remains vulnerable to follow-up extortion."
    ),
    ScenarioItem(
        id="scen-normal-grocery",
        title="Verified Merchant Grocery Checkout (Safe Baseline)",
        subtitle="Standard Legitimate Transaction",
        scam_category="NORMAL",
        icon_name="CheckCircle2",
        sample_request=TransactionScanRequest(
            sender_vpa="rohit.verma@okicici",
            payee_vpa="dmart.retail@axisbank",
            payee_name="DMart Supermarket Retail",
            amount=1845.50,
            channel="STATIC_QR",
            note="Weekly grocery bill",
            payee_account_age_days=780,
            payee_velocity_1h=3,
            device_signals=DeviceRiskSignals(
                remote_access_app_detected=False,
                screen_sharing_active=False,
                call_in_progress=False,
                is_new_device=False,
                is_rooted_or_jailbroken=False,
                ip_vpn_or_proxy=False
            )
        ),
        context_story="Regular shopper scanning the verified merchant billing QR at DMart checkout counter.",
        modus_operandi="No threat indicators. High merchant account age, normal velocity, zero remote app signals.",
        what_would_happen_without_ai="Transaction is processed normally without false alarms."
    )
]

@router.get("/list", response_model=List[ScenarioItem])
def list_scenarios():
    return PRESET_SCENARIOS

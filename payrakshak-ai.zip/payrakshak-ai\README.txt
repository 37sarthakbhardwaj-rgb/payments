================================================================================
PayRakshak AI (पे-रक्षक AI)
CyberCup 6.0 | Problem Statement CCG-AI02: AI Detection of Creative Payment Frauds
================================================================================
Tagline: Detect the scam. Explain the risk. Protect the payment.

--------------------------------------------------------------------------------
1. PROJECT OVERVIEW
--------------------------------------------------------------------------------
PayRakshak AI is an AI-powered cybersecurity and payment fraud detection platform
designed specifically for India's digital payment ecosystem (UPI, dynamic QR codes,
payment links, and collect requests).

The system intercepts transactions and payment messages BEFORE user authorization
and PIN submission, identifying both conventional fraud and 7 creative scam archetypes:

  1. Fake Collect Requests and Refund Scams (UPI PIN Inversion Deception)
  2. QR-Code Payment Scams (Malicious Scan-to-Receive Traps)
  3. Fake Customer-Care Numbers & Remote-Access Apps (AnyDesk / TeamViewer)
  4. Fake Investment & Job-Offer Payment Requests (Telegram VIP Task Syndicates)
  5. Mule-Account and Suspicious Beneficiary Velocity Patterns
  6. Phishing SMS and Malicious Payment Links (.apk Trojans & Masked URLs)
  7. Fake KYC Updates and Account-Blocking Threats (Electricity Cutoff Panics)

--------------------------------------------------------------------------------
2. EVALUATION BENCHMARKS & STATISTICS
--------------------------------------------------------------------------------
Offline Machine Learning Benchmark (Independent Test Split of 1,200 Labeled Txns):
  * Fraud Detection Rate (Recall): 96.8%
  * False Positive Rate (FPR):     1.2%
  * Accuracy:                     97.4%
  * Precision:                    94.2%
  * F1-Score:                     95.5%
  * ROC-AUC:                      0.991

Live Demo Statistics:
  * Processed in real-time from active SQLite database
  * 180+ historical transactions pre-seeded across all 7 fraud categories
  * Real-time explainability attribution with exact factor contribution weights

--------------------------------------------------------------------------------
3. TECHNOLOGY STACK
--------------------------------------------------------------------------------
Frontend:
  * React 19 with Vite & TypeScript
  * Tailwind CSS (Custom Dark Navy & Electric Cyan Cyber Theme)
  * Recharts (Interactive Area, Donut, and Bar Analytics)
  * Lucide Icons
  * Vitest for frontend unit testing

Backend:
  * Python 3.12 with FastAPI
  * Pydantic v2 for robust schema validation
  * SQLAlchemy with SQLite (clean migration path to PostgreSQL)
  * Scikit-learn (Random Forest Ensemble + TF-IDF Vectorizer + Multinomial Naive Bayes)
  * Pandas, NumPy, and Joblib
  * Pytest & HTTPX for API integration testing

--------------------------------------------------------------------------------
4. HOW TO RUN THE PROJECT (WINDOWS / POWERSHELL)
--------------------------------------------------------------------------------
Prerequisites:
  * Python 3.12 (available via 'py -3.12' or 'python')
  * Node.js v18+ and npm

Step 1: Setup Backend
  cd payrakshak-ai
  py -3.12 -m venv venv
  .\venv\Scripts\pip.exe install -r backend\requirements.txt

Step 2: Setup Frontend
  cd frontend
  npm install
  cd ..

Step 3: Launch Services
  Option A - One-Click Launcher:
    .\start.ps1

  Option B - Separate Windows:
    Terminal 1 (Backend):
      .\run_backend.ps1
      (Service runs at http://localhost:8000 | Docs at http://localhost:8000/docs)

    Terminal 2 (Frontend):
      .\run_frontend.ps1
      (Service runs at http://localhost:5173)

--------------------------------------------------------------------------------
5. RUNNING THE AUTOMATED TEST SUITE
--------------------------------------------------------------------------------
To run the complete full-stack automated test suite:
  .\run_tests.ps1

  Backend Tests:  9 passed (Pytest + HTTPX)
  Frontend Tests: 3 passed (Vitest)
  Status:         SUCCESS (100% pass rate)

--------------------------------------------------------------------------------
6. REPOSITORY STRUCTURE
--------------------------------------------------------------------------------
payrakshak-ai/
  |-- backend/
  |     |-- app/
  |     |     |-- api/             # REST endpoints (transactions, messages, analytics)
  |     |     |-- core/            # Config and database session
  |     |     |-- models/          # DB models & Pydantic schemas
  |     |     |-- services/        # Rule engine, ML engine, NLP engine, seeder
  |     |     |-- ml/              # Trained model joblib artifacts
  |     |     `-- main.py          # FastAPI application entrypoint
  |     |-- tests/                 # Backend automated test suite
  |     `-- requirements.txt       # Python dependencies
  |-- frontend/
  |     |-- src/
  |     |     |-- components/      # UI components (Navbar, Sidebar, Badges, Modals)
  |     |     |-- pages/           # 6 core dashboards and simulators
  |     |     |-- services/        # API client
  |     |     |-- types/           # TypeScript interfaces
  |     |     `-- tests/           # Vitest component tests
  |     |-- package.json
  |     `-- tailwind.config.js
  |-- payrakshak.db                # SQLite database pre-seeded with live data
  |-- run_backend.ps1              # Backend runner script
  |-- run_frontend.ps1             # Frontend runner script
  |-- run_tests.ps1                # Automated full-stack test runner
  |-- start.ps1                    # One-click launcher script
  |-- README.md                    # Detailed Markdown documentation
  `-- README.txt                   # Plain text project guide
================================================================================

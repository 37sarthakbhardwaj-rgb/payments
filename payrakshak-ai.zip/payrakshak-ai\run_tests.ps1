Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   PayRakshak AI -- Full Stack Test Suite" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

$env:PYTHONPATH = "backend"
.\venv\Scripts\pytest.exe backend\tests -v
$backendExit = $LASTEXITCODE

Set-Location -Path "frontend"
npm test
$frontendExit = $LASTEXITCODE
Set-Location -Path ".."

if ($backendExit -eq 0 -and $frontendExit -eq 0) {
    Write-Host "SUCCESS: All tests passed!" -ForegroundColor Green
} else {
    Write-Host "FAILURE: One or more tests failed." -ForegroundColor Red
}

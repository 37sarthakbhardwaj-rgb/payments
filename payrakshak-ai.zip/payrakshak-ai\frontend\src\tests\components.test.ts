import { describe, it, expect } from 'vitest';

describe('PayRakshak AI Frontend Logic Tests', () => {
  it('correctly categorizes risk score thresholds', () => {
    const getRiskTier = (score: number) => {
      if (score >= 80) return 'CRITICAL';
      if (score >= 60) return 'HIGH';
      if (score >= 35) return 'MODERATE';
      if (score >= 20) return 'LOW';
      return 'SAFE';
    };

    expect(getRiskTier(95)).toBe('CRITICAL');
    expect(getRiskTier(82)).toBe('CRITICAL');
    expect(getRiskTier(75)).toBe('HIGH');
    expect(getRiskTier(50)).toBe('MODERATE');
    expect(getRiskTier(25)).toBe('LOW');
    expect(getRiskTier(10)).toBe('SAFE');
  });

  it('formats Indian rupee amounts properly', () => {
    const formatINR = (amt: number) => {
      return `₹${amt.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
    };

    expect(formatINR(15000)).toBe('₹15,000.00');
    expect(formatINR(49000)).toBe('₹49,000.00');
    expect(formatINR(1.0)).toBe('₹1.00');
  });

  it('validates UPI VPA syntax pattern', () => {
    const isValidVpa = (vpa: string) => {
      return /^[\w\.\-]+@[\w]+$/.test(vpa);
    };

    expect(isValidVpa('rahul@okaxis')).toBe(true);
    expect(isValidVpa('olx.buyer.pay@ybl')).toBe(true);
    expect(isValidVpa('invalid-vpa-without-at')).toBe(false);
  });
});

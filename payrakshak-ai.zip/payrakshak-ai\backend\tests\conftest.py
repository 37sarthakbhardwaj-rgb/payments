import pytest
from app.core.database import Base, engine, SessionLocal
from app.services.database_seeder import seed_database_if_empty

@pytest.fixture(scope="session", autouse=True)
def setup_test_db():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_database_if_empty(db)
    finally:
        db.close()
    yield

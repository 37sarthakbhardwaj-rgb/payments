import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  Smartphone,
  Lock,
  PhoneCall,
  Activity,
  Layers,
  ArrowRight,
  CheckCircle2,
  HelpCircle,
  ExternalLink
} from 'lucide-react';
import { api } from '../services/api';
import { RiskBadge } from '../components/RiskBadge';
import {
  TransactionScanRequest,
  TransactionScanResponse,
  ScenarioItem,
  DeviceRiskSignals
} from '../types';

export const TransactionScanner: React.FC = () => {
  const [scenarios, setScenarios] = useState<ScenarioItem[]>([]);
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<TransactionScanResponse | null>(null);

  // Form State
  const [senderVpa, setSenderVpa] = useState('rahul.verma@okaxis');
  const [payeeVpa, setPayeeVpa] = useState('olx.buyer.pay@ybl');
  const [payeeName, setPayeeName] = useState('OLX Buyer Verification Desk');
  const [amount, setAmount] = useState<number>(15000);
  const [channel, setChannel] = useState('COLLECT_REQUEST');
  const [note, setNote] = useState('Approve collect request and enter UPI PIN to receive money for your sofa');
  const [payeeAccountAge, setPayeeAccountAge] = useState<number>(3);
  const [payeeVelocity, setPayeeVelocity] = useState<number>(19);

  // Device Signals
  const [remoteApp, setRemoteApp] = useState(false);
  const [screenShare, setScreenShare] = useState(false);
  const [callInProgress, setCallInProgress] = useState(true);
  const [newDevice, setNewDevice] = useState(false);
  const [rooted, setRooted] = useState(false);
  const [vpn, setVpn] = useState(false);

  useEffect(() => {
    api.getScenarios().then((data) => {
      setScenarios(data);
      if (data.length > 0) {
        setSelectedScenarioId(data[0].id);
        loadScenario(data[0]);
      }
    }).catch(console.error);
  }, []);

  const loadScenario = (scen: ScenarioItem) => {
    const req = scen.sample_request;
    setSenderVpa(req.sender_vpa);
    setPayeeVpa(req.payee_vpa);
    setPayeeName(req.payee_name);
    setAmount(req.amount);
    setChannel(req.channel);
    setNote(req.note || '');
    setPayeeAccountAge(req.payee_account_age_days ?? 3);
    setPayeeVelocity(req.payee_velocity_1h ?? 1);

    const dev = req.device_signals;
    setRemoteApp(dev?.remote_access_app_detected ?? false);
    setScreenShare(dev?.screen_sharing_active ?? false);
    setCallInProgress(dev?.call_in_progress ?? false);
    setNewDevice(dev?.is_new_device ?? false);
    setRooted(dev?.is_rooted_or_jailbroken ?? false);
    setVpn(dev?.ip_vpn_or_proxy ?? false);
  };

  const handleScenarioSelect = (id: string) => {
    setSelectedScenarioId(id);
    const scen = scenarios.find((s) => s.id === id);
    if (scen) loadScenario(scen);
  };

  const handleScan = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);
    try {
      const payload: TransactionScanRequest = {
        sender_vpa: senderVpa,
        payee_vpa: payeeVpa,
        payee_name: payeeName,
        amount: Number(amount),
        channel: channel,
        note: note,
        payee_account_age_days: Number(payeeAccountAge),
        payee_velocity_1h: Number(payeeVelocity),
        device_signals: {
          remote_access_app_detected: remoteApp,
          screen_sharing_active: screenShare,
          call_in_progress: callInProgress,
          is_new_device: newDevice,
          is_rooted_or_jailbroken: rooted,
          ip_vpn_or_proxy: vpn,
        },
      };

      const res = await api.scanTransaction(payload);
      setScanResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-navy-900 border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldCheck className="h-5 w-5 text-cyan-400" />
            <h1 className="text-xl font-bold text-white tracking-tight">
              Real-Time UPI Transaction Scanner
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-400 max-w-xl">
            Inspect live payment requests against the hybrid AI engine (Random Forest ensemble + NLP + expert Indian payment heuristics).
          </p>
        </div>

        {/* Quick Scenario Preset Loader */}
        <div className="flex items-center space-x-2 bg-navy-950 p-2 rounded-xl border border-slate-800">
          <Sparkles className="h-4 w-4 text-cyan-400 shrink-0 ml-1" />
          <span className="text-xs font-mono text-slate-400 shrink-0">Preset Scenario:</span>
          <select
            value={selectedScenarioId}
            onChange={(e) => handleScenarioSelect(e.target.value)}
            className="bg-navy-900 border border-slate-700 text-xs font-mono text-slate-200 rounded-lg px-2.5 py-1.5 focus:border-cyan-400 focus:outline-none"
          >
            {scenarios.map((s) => (
              <option key={s.id} value={s.id}>
                {s.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid: Form on Left, AI Results on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Transaction Input Form */}
        <div className="lg:col-span-6 space-y-4">
          <form onSubmit={handleScan} className="bg-navy-900/90 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-xl">
            <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
              <span className="text-xs font-mono font-semibold uppercase tracking-wider text-cyan-400">
                1. Transaction & Payee Parameters
              </span>
              <span className="text-[11px] font-mono text-slate-500">Simulate UPI Context</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">
                  Sender UPI ID (Victim / Payer)
                </label>
                <input
                  type="text"
                  value={senderVpa}
                  onChange={(e) => setSenderVpa(e.target.value)}
                  className="w-full bg-navy-950 border border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">
                  Payee UPI ID (Beneficiary)
                </label>
                <input
                  type="text"
                  value={payeeVpa}
                  onChange={(e) => setPayeeVpa(e.target.value)}
                  className="w-full bg-navy-950 border border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">
                  Payee Registered Name
                </label>
                <input
                  type="text"
                  value={payeeName}
                  onChange={(e) => setPayeeName(e.target.value)}
                  className="w-full bg-navy-950 border border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">
                  Amount (INR ₹)
                </label>
                <input
                  type="number"
                  step="any"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full bg-navy-950 border border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none font-bold"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">
                  Payment Channel
                </label>
                <select
                  value={channel}
                  onChange={(e) => setChannel(e.target.value)}
                  className="w-full bg-navy-950 border border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                >
                  <option value="COLLECT_REQUEST">COLLECT_REQUEST (Pull Payment)</option>
                  <option value="STATIC_QR">STATIC_QR (Printed QR Code)</option>
                  <option value="DYNAMIC_QR">DYNAMIC_QR (Screen QR Code)</option>
                  <option value="INTENT">INTENT (App-to-App P2P / P2M)</option>
                  <option value="PAYMENT_LINK">PAYMENT_LINK (SMS / Web Link)</option>
                  <option value="NETBANKING">NETBANKING (Gateway API)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">
                  Payee Account Age (Days)
                </label>
                <input
                  type="number"
                  value={payeeAccountAge}
                  onChange={(e) => setPayeeAccountAge(Number(e.target.value))}
                  className="w-full bg-navy-950 border border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">
                  Payee Velocity (Txns in last 1h)
                </label>
                <input
                  type="number"
                  value={payeeVelocity}
                  onChange={(e) => setPayeeVelocity(Number(e.target.value))}
                  className="w-full bg-navy-950 border border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">
                  Payment Note / Narration
                </label>
                <input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="e.g. Click to receive refund"
                  className="w-full bg-navy-950 border border-slate-700/80 rounded-lg px-3 py-2 text-xs font-mono text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>

            {/* Device & Hardware Security Signals */}
            <div className="pt-3 border-t border-slate-800">
              <span className="text-[11px] font-mono font-semibold uppercase tracking-wider text-cyan-400 block mb-2">
                2. Device Security & Behavioral Signals
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs font-mono">
                <label className={`p-2.5 rounded-lg border cursor-pointer transition-all flex items-center space-x-2 ${
                  remoteApp ? 'bg-red-500/15 border-red-500/40 text-red-300' : 'bg-navy-950 border-slate-800 text-slate-400'
                }`}>
                  <input
                    type="checkbox"
                    checked={remoteApp}
                    onChange={(e) => setRemoteApp(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-red-500 focus:ring-0"
                  />
                  <span className="text-[11px]">AnyDesk / Remote App</span>
                </label>

                <label className={`p-2.5 rounded-lg border cursor-pointer transition-all flex items-center space-x-2 ${
                  screenShare ? 'bg-red-500/15 border-red-500/40 text-red-300' : 'bg-navy-950 border-slate-800 text-slate-400'
                }`}>
                  <input
                    type="checkbox"
                    checked={screenShare}
                    onChange={(e) => setScreenShare(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-red-500 focus:ring-0"
                  />
                  <span className="text-[11px]">Screen Share Active</span>
                </label>

                <label className={`p-2.5 rounded-lg border cursor-pointer transition-all flex items-center space-x-2 ${
                  callInProgress ? 'bg-amber-500/15 border-amber-500/40 text-amber-300' : 'bg-navy-950 border-slate-800 text-slate-400'
                }`}>
                  <input
                    type="checkbox"
                    checked={callInProgress}
                    onChange={(e) => setCallInProgress(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-amber-500 focus:ring-0"
                  />
                  <span className="text-[11px]">Active Voice Call</span>
                </label>

                <label className={`p-2.5 rounded-lg border cursor-pointer transition-all flex items-center space-x-2 ${
                  newDevice ? 'bg-amber-500/15 border-amber-500/40 text-amber-300' : 'bg-navy-950 border-slate-800 text-slate-400'
                }`}>
                  <input
                    type="checkbox"
                    checked={newDevice}
                    onChange={(e) => setNewDevice(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-amber-500 focus:ring-0"
                  />
                  <span className="text-[11px]">New Device (48h)</span>
                </label>

                <label className={`p-2.5 rounded-lg border cursor-pointer transition-all flex items-center space-x-2 ${
                  rooted ? 'bg-red-500/15 border-red-500/40 text-red-300' : 'bg-navy-950 border-slate-800 text-slate-400'
                }`}>
                  <input
                    type="checkbox"
                    checked={rooted}
                    onChange={(e) => setRooted(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-red-500 focus:ring-0"
                  />
                  <span className="text-[11px]">Rooted / Jailbroken</span>
                </label>

                <label className={`p-2.5 rounded-lg border cursor-pointer transition-all flex items-center space-x-2 ${
                  vpn ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300' : 'bg-navy-950 border-slate-800 text-slate-400'
                }`}>
                  <input
                    type="checkbox"
                    checked={vpn}
                    onChange={(e) => setVpn(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
                  />
                  <span className="text-[11px]">VPN / Proxy Active</span>
                </label>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex items-center space-x-3">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 py-3 px-4 rounded-xl font-bold font-mono text-xs text-navy-950 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 shadow-lg shadow-cyan-500/25 flex items-center justify-center space-x-2 transition-all"
              >
                {loading ? (
                  <span className="flex items-center space-x-2">
                    <span className="h-4 w-4 border-2 border-navy-950 border-t-transparent rounded-full animate-spin" />
                    <span>Evaluating Risk...</span>
                  </span>
                ) : (
                  <>
                    <Play className="h-4 w-4 fill-navy-950" />
                    <span>RUN AI FRAUD ANALYSIS</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: AI Detection & Explainability Output */}
        <div className="lg:col-span-6 space-y-4">
          {scanResult ? (
            <div className="bg-navy-900/90 rounded-2xl border border-slate-800 p-5 space-y-5 shadow-2xl">
              {/* Top Decision Header */}
              <div className="flex items-start justify-between border-b border-slate-800 pb-4">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500">
                    Decision Outcome
                  </span>
                  <div className="flex items-center space-x-3 mt-1">
                    <RiskBadge tier={scanResult.risk_tier} size="lg" />
                    <span className="text-xs font-mono text-slate-400">
                      ID: <span className="text-white">{scanResult.transaction_id}</span>
                    </span>
                  </div>
                </div>

                {/* Cyber Gauge Score Meter */}
                <div className="text-right">
                  <span className="text-[10px] font-mono uppercase text-slate-500 block">
                    AI Risk Score
                  </span>
                  <div
                    className={`text-3xl font-extrabold font-mono tracking-tight ${
                      scanResult.risk_score >= 80
                        ? 'text-red-400 animate-pulse'
                        : scanResult.risk_score >= 50
                        ? 'text-amber-400'
                        : 'text-emerald-400'
                    }`}
                  >
                    {scanResult.risk_score}
                    <span className="text-sm font-normal text-slate-500">/100</span>
                  </div>
                </div>
              </div>

              {/* Action Banner */}
              <div
                className={`p-4 rounded-xl border flex items-center justify-between text-xs font-mono ${
                  scanResult.recommended_action === 'BLOCK_TRANSACTION'
                    ? 'bg-red-500/10 border-red-500/30 text-red-300'
                    : scanResult.recommended_action === 'CHALLENGE_PIN_COOLING'
                    ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                    : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                }`}
              >
                <div>
                  <span className="text-[10px] uppercase block text-slate-400 font-sans">
                    Recommended Policy Action
                  </span>
                  <span className="text-sm font-bold">{scanResult.recommended_action}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase block text-slate-400 font-sans">
                    Detected Pattern
                  </span>
                  <span className="text-xs font-bold">{scanResult.scam_category}</span>
                </div>
              </div>

              {/* Explainability Summary */}
              <div className="p-4 rounded-xl bg-navy-950 border border-slate-800">
                <h4 className="text-xs font-bold text-white flex items-center space-x-2 mb-1.5">
                  <ShieldAlert className="h-4 w-4 text-cyan-400" />
                  <span>Explainability: Why Was This Flagged?</span>
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {scanResult.explanation_summary}
                </p>
              </div>

              {/* Factor Contribution Breakdown */}
              {scanResult.risk_factors.length > 0 && (
                <div>
                  <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
                    Attribution Breakdown (Factor Weights)
                  </h4>
                  <div className="space-y-2">
                    {scanResult.risk_factors.map((factor, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-navy-950 border border-slate-800/80 flex items-center justify-between text-xs"
                      >
                        <div className="pr-2">
                          <span className="font-semibold text-slate-200 block text-xs">
                            {factor.factor_name}
                          </span>
                          <span className="text-slate-400 text-[11px] block">
                            {factor.description}
                          </span>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <span
                            className={`font-mono font-bold ${
                              factor.impact_score > 0 ? 'text-red-400' : 'text-emerald-400'
                            }`}
                          >
                            {factor.impact_score > 0 ? `+${factor.impact_score}` : factor.impact_score}%
                          </span>
                          <span className="block text-[9px] text-slate-500 font-mono">
                            {factor.severity}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Triggered Rules */}
              {scanResult.rules_triggered.length > 0 && (
                <div>
                  <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-2">
                    Triggered Expert Rules ({scanResult.rules_triggered.length})
                  </h4>
                  <div className="space-y-1.5">
                    {scanResult.rules_triggered.map((rule, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs"
                      >
                        <div className="flex items-center justify-between font-mono">
                          <span className="text-amber-400 font-bold">{rule.rule_code}</span>
                          <span className="text-[10px] text-amber-300 px-1.5 py-0.5 rounded bg-amber-500/20">
                            {rule.severity}
                          </span>
                        </div>
                        <p className="mt-1 text-slate-300 text-[11px]">{rule.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Victim Guidance / Preventive Steps */}
              {scanResult.prevention_steps.length > 0 && (
                <div className="p-4 rounded-xl bg-cyan-950/20 border border-cyan-500/30">
                  <h4 className="text-xs font-semibold text-cyan-300 flex items-center space-x-1.5 mb-2">
                    <CheckCircle2 className="h-4 w-4 text-cyan-400" />
                    <span>Mitigation Guidance</span>
                  </h4>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {scanResult.prevention_steps.map((step, idx) => (
                      <li key={idx} className="flex items-start space-x-2">
                        <span className="text-cyan-400 font-bold">•</span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ) : (
            <div className="h-full min-h-[400px] flex flex-col items-center justify-center p-8 rounded-2xl bg-navy-900/40 border border-dashed border-slate-800 text-center">
              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 mb-3">
                <ShieldCheck className="h-8 w-8" />
              </div>
              <h3 className="text-sm font-bold text-white">No Scan Executed Yet</h3>
              <p className="mt-1 text-xs text-slate-400 max-w-sm">
                Select a preset scenario on the left or customize your transaction and device parameters, then click <strong>RUN AI FRAUD ANALYSIS</strong>.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { Shield, Sparkles, AlertCircle, RefreshCw, Menu } from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  onRefresh,
  isRefreshing,
}) => {
  return (
    <header className="h-16 border-b border-slate-800/80 bg-navy-900/80 backdrop-blur-md px-6 flex items-center justify-between sticky top-0 z-40">
      <div className="flex items-center space-x-3">
        <div className="md:hidden flex items-center space-x-2">
          <div className="h-8 w-8 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center">
            <Shield className="h-4 w-4 text-cyan-400" />
          </div>
          <span className="font-bold text-sm text-white">PayRakshak AI</span>
        </div>

        <div className="hidden md:flex items-center space-x-2 text-xs font-mono">
          <span className="text-slate-400">Tagline:</span>
          <span className="italic text-cyan-300">"Detect the scam. Explain the risk. Protect the payment."</span>
        </div>
      </div>

      <div className="flex items-center space-x-3">
        {/* Status Pill */}
        <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="text-[11px] font-mono text-emerald-400 font-medium">Real-Time AI Active</span>
        </div>

        {/* Quick Refresh */}
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-400 transition-colors border border-slate-700/60"
            title="Refresh statistics"
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`} />
          </button>
        )}
      </div>
    </header>
  );
};

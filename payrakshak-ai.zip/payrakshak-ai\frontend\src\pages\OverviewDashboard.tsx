import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Activity,
  Layers,
  ArrowUpRight,
  Info,
  ExternalLink,
  Cpu,
  CheckCircle2,
  Filter
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend
} from 'recharts';
import { api } from '../services/api';
import { MetricCard } from '../components/MetricCard';
import { RiskBadge } from '../components/RiskBadge';
import { ExplanationModal } from '../components/ExplanationModal';
import {
  OverviewStats,
  FraudCategoryStat,
  RiskLevelStat,
  ActivityTimePoint,
  TransactionSummaryItem
} from '../types';

const COLORS = ['#06B6D4', '#3B82F6', '#8B5CF6', '#EC4899', '#F97316', '#EAB308', '#EF4444', '#10B981'];

export const OverviewDashboard: React.FC = () => {
  const [stats, setStats] = useState<OverviewStats | null>(null);
  const [categories, setCategories] = useState<FraudCategoryStat[]>([]);
  const [activity, setActivity] = useState<ActivityTimePoint[]>([]);
  const [riskDistribution, setRiskDistribution] = useState<RiskLevelStat[]>([]);
  const [flaggedTransactions, setFlaggedTransactions] = useState<TransactionSummaryItem[]>([]);
  const [selectedTxn, setSelectedTxn] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<'flagged' | 'high_risk' | 'all'>('flagged');

  const fetchData = async () => {
    try {
      setLoading(true);
      const [statsData, catData, actData, riskData, txnsData] = await Promise.all([
        api.getOverviewStats(),
        api.getCategories(),
        api.getActivity(),
        api.getRiskDistribution(),
        api.getRecentTransactions(filterType, 20)
      ]);
      setStats(statsData);
      setCategories(catData);
      setActivity(actData);
      setRiskDistribution(riskData);
      setFlaggedTransactions(txnsData);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [filterType]);

  const handleTxnClick = async (id: string) => {
    try {
      const details = await api.getTransactionDetail(id);
      setSelectedTxn(details);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Problem Statement Callout */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-navy-900 via-navy-850 to-navy-950 p-6 border border-cyan-500/20 shadow-xl">
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-56 h-56 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                CYBERCUP 6.0 · PROBLEM STATEMENT CCG-AI02
              </span>
              <span className="text-xs text-slate-400 font-mono">Real-Time UPI Scam Interceptor</span>
            </div>
            <h1 className="mt-2 text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              AI Detection of Creative Payment Frauds
            </h1>
            <p className="mt-1 text-sm text-slate-300 max-w-2xl leading-relaxed">
              Detects conventional payment anomalies and creative Indian UPI scams (fake collect requests, AnyDesk remote-support scams, QR traps, task syndicates, and KYC extortion) before user authorization.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 shrink-0">
            <div className="bg-navy-950/80 px-4 py-2.5 rounded-xl border border-slate-800 text-left font-mono">
              <span className="text-[10px] text-slate-500 uppercase block">Engine State</span>
              <span className="text-xs font-semibold text-emerald-400 flex items-center space-x-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>Active Protection</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Primary KPI Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <MetricCard
          title="Total Transactions Analyzed"
          value={stats ? stats.total_transactions_analyzed.toLocaleString() : '---'}
          subtitle="Processed in database"
          icon={Activity}
          variant="cyan"
          badge="Live Demo Data"
        />
        <MetricCard
          title="Flagged Suspicious"
          value={stats ? stats.flagged_suspicious_count.toLocaleString() : '---'}
          subtitle={stats ? `${stats.fraud_share_percentage}% of total stream` : ''}
          icon={ShieldAlert}
          variant="amber"
          badge="Pending / Warning"
        />
        <MetricCard
          title="High & Critical Risk"
          value={stats ? stats.high_critical_risk_count.toLocaleString() : '---'}
          subtitle="Auto-blocked / Cooling"
          icon={AlertTriangle}
          variant="red"
          badge="Scam Signatures"
        />
        <MetricCard
          title="Offline Detection Rate"
          value={stats ? `${stats.offline_fraud_detection_rate}%` : '---'}
          subtitle="Recall on test dataset"
          icon={Cpu}
          variant="green"
          badge="Test Split (N=1,200)"
        />
        <MetricCard
          title="Offline False-Positive Rate"
          value={stats ? `${stats.offline_false_positive_rate}%` : '---'}
          subtitle="Low consumer friction"
          icon={CheckCircle2}
          variant="cyan"
          badge="FPR = FP / (FP+TN)"
        />
      </div>

      {/* Live Demo Statistics vs Offline ML Evaluation Metrics Explanation Callout */}
      <div className="rounded-xl bg-navy-900/90 border border-cyan-500/20 p-4.5 shadow-lg">
        <div className="flex items-start space-x-3.5">
          <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 flex-shrink-0 mt-0.5">
            <Info className="h-5 w-5" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <h3 className="text-sm font-semibold text-white">
                Understanding Metrics: Live Demo Statistics vs. Offline Model Evaluation
              </h3>
              <span className="text-[10px] font-mono bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded border border-cyan-500/30">
                Evaluation Integrity
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {stats?.live_vs_offline_explanation ||
                'Offline model evaluation metrics (e.g. 96.8% Detection Rate and 1.2% FPR) represent rigorous benchmark performance measured on a held-out test split of 1,200 pre-labeled synthetic transactions. In contrast, Live Demo Statistics reflect real-time counts from this application’s active transactional database.'}
            </p>
          </div>
        </div>
      </div>

      {/* Visual Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Transaction Activity Over Time */}
        <div className="lg:col-span-2 rounded-2xl bg-navy-900/90 border border-slate-800 p-5 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <Activity className="h-4 w-4 text-cyan-400" />
                <span>Transaction Activity & Detection Timeline</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Volume of legitimate payments vs. intercepted suspicious attempts
              </p>
            </div>
            <div className="flex items-center space-x-3 text-xs font-mono">
              <span className="flex items-center space-x-1.5 text-cyan-400">
                <span className="h-2.5 w-2.5 rounded-sm bg-cyan-500"></span>
                <span>Legitimate</span>
              </span>
              <span className="flex items-center space-x-1.5 text-red-400">
                <span className="h-2.5 w-2.5 rounded-sm bg-red-500"></span>
                <span>Flagged</span>
              </span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activity} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorLegit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06B6D4" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorFlagged" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.5} />
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time_label" stroke="#64748B" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontFamily: 'monospace',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="legitimate_volume"
                  name="Legitimate"
                  stroke="#06B6D4"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorLegit)"
                />
                <Area
                  type="monotone"
                  dataKey="flagged_volume"
                  name="Flagged"
                  stroke="#EF4444"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorFlagged)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Risk Level Distribution */}
        <div className="rounded-2xl bg-navy-900/90 border border-slate-800 p-5 shadow-lg flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Layers className="h-4 w-4 text-cyan-400" />
              <span>Risk Tier Breakdown</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Real-time risk scoring classification</p>
          </div>

          <div className="h-52 w-full my-auto">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={riskDistribution}
                  dataKey="count"
                  nameKey="tier"
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                >
                  {riskDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontFamily: 'monospace',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
            {riskDistribution.map((r) => (
              <div key={r.tier} className="flex items-center justify-between text-xs font-mono">
                <div className="flex items-center space-x-2">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: r.color }} />
                  <span className="text-slate-300">{r.tier}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-white font-semibold">{r.count}</span>
                  <span className="text-slate-500 text-[11px]">({r.percentage}%)</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Fraud Category Distribution Horizontal Bar Breakdown */}
      <div className="rounded-2xl bg-navy-900/90 border border-slate-800 p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <ShieldAlert className="h-4 w-4 text-cyan-400" />
              <span>Fraud Category Distribution (7 Creative Fraud Archetypes)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Breakdown of detected transactions by Indian digital payment scam category
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {categories
            .filter((c) => c.category !== 'NORMAL')
            .map((cat, idx) => (
              <div
                key={cat.category}
                className="p-3.5 rounded-xl bg-navy-950 border border-slate-800/80 hover:border-cyan-500/30 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      #{idx + 1}
                    </span>
                    <span className="text-xs font-mono font-bold text-cyan-400">
                      {cat.count} txns
                    </span>
                  </div>
                  <h4 className="mt-2 text-xs font-bold text-white line-clamp-1">{cat.sample_scam_name}</h4>
                  <p className="text-[11px] font-mono text-slate-400 mt-0.5">{cat.category}</p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
                  <span className="text-slate-500">Avg Risk Score:</span>
                  <span className="text-amber-400 font-bold">{cat.avg_risk_score}/100</span>
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Recent Flagged Transactions Table */}
      <div className="rounded-2xl bg-navy-900/90 border border-slate-800 p-5 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Activity className="h-4 w-4 text-cyan-400" />
              <span>Recent Transaction Stream</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Click any transaction row to open comprehensive AI explainability & mitigation steps
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center space-x-1.5 bg-navy-950 p-1 rounded-lg border border-slate-800 self-start">
            <button
              onClick={() => setFilterType('flagged')}
              className={`px-3 py-1 rounded text-xs font-medium font-mono transition-all ${
                filterType === 'flagged'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Flagged Only
            </button>
            <button
              onClick={() => setFilterType('high_risk')}
              className={`px-3 py-1 rounded text-xs font-medium font-mono transition-all ${
                filterType === 'high_risk'
                  ? 'bg-red-500/20 text-red-300 border border-red-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              High/Critical
            </button>
            <button
              onClick={() => setFilterType('all')}
              className={`px-3 py-1 rounded text-xs font-medium font-mono transition-all ${
                filterType === 'all'
                  ? 'bg-slate-800 text-white border border-slate-700'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All Records
            </button>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="overflow-x-auto rounded-xl border border-slate-800/80">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3">Txn ID</th>
                <th className="p-3">Amount</th>
                <th className="p-3">Channel</th>
                <th className="p-3">Payee VPA & Name</th>
                <th className="p-3">Risk Tier</th>
                <th className="p-3">Category</th>
                <th className="p-3">Action</th>
                <th className="p-3 text-right">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-navy-900/60">
              {flaggedTransactions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500">
                    No transactions match current filter.
                  </td>
                </tr>
              ) : (
                flaggedTransactions.map((txn) => (
                  <tr
                    key={txn.id}
                    onClick={() => handleTxnClick(txn.id)}
                    className="hover:bg-slate-800/40 cursor-pointer transition-colors group"
                  >
                    <td className="p-3 text-cyan-400 font-semibold">{txn.id}</td>
                    <td className="p-3 font-bold text-white">
                      ₹{txn.amount?.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="p-3 text-slate-300">
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-[11px]">
                        {txn.channel}
                      </span>
                    </td>
                    <td className="p-3">
                      <div className="text-slate-200 font-medium truncate max-w-[160px]">
                        {txn.payee_name}
                      </div>
                      <div className="text-slate-500 text-[10px] truncate max-w-[160px]">
                        {txn.payee_vpa}
                      </div>
                    </td>
                    <td className="p-3">
                      <RiskBadge tier={txn.risk_tier} size="sm" />
                    </td>
                    <td className="p-3">
                      <span className="text-[11px] text-slate-300 font-mono">
                        {txn.scam_category || 'NORMAL'}
                      </span>
                    </td>
                    <td className="p-3">
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                          txn.recommended_action === 'BLOCK_TRANSACTION'
                            ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                            : txn.recommended_action === 'CHALLENGE_PIN_COOLING'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-emerald-500/20 text-emerald-400'
                        }`}
                      >
                        {txn.recommended_action}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <span className="inline-flex items-center text-cyan-400 group-hover:text-cyan-300 space-x-1 text-[11px]">
                        <span>Details</span>
                        <ArrowUpRight className="h-3.5 w-3.5" />
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Explainability Modal */}
      {selectedTxn && (
        <ExplanationModal transaction={selectedTxn} onClose={() => setSelectedTxn(null)} />
      )}
    </div>
  );
};

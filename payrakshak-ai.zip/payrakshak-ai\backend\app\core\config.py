import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "PayRakshak AI"
    TAGLINE: str = "Detect the scam. Explain the risk. Protect the payment."
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    
    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./payrakshak.db")
    
    # Model storage directory
    ML_MODEL_DIR: str = os.path.join(os.path.dirname(os.path.dirname(__file__)), "ml")
    
    # CORS
    CORS_ORIGINS: list[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://localhost:8000",
        "*"
    ]

    class Config:
        case_sensitive = True

settings = Settings()

import uuid
import datetime
import random
import pandas as pd
from sqlalchemy.orm import Session
from app.models.db_models import TransactionRecord, MessageScanRecord, ThreatIntelligence, ModelEvaluationLog
from app.services.ml_engine import MLEngine
from app.services.synthetic_data import generate_synthetic_transactions

INITIAL_THREAT_INTEL = [
    {
        "indicator_type": "VPA",
        "indicator_value": "olx.buyer.pay@ybl",
        "threat_category": "FAKE_COLLECT_REFUND_SCAM",
        "risk_level": "CRITICAL",
        "description": "Known OLX buyer collect request scammer posing as army officer.",
        "source": "I4C / 1930 Cyber Helpline"
    },
    {
        "indicator_type": "VPA",
        "indicator_value": "gpay.refund.portal@paytm",
        "threat_category": "FAKE_COLLECT_REFUND_SCAM",
        "risk_level": "CRITICAL",
        "description": "Impersonating Google Pay refund executive.",
        "source": "NPCI Security Advisory"
    },
    {
        "indicator_type": "URL",
        "indicator_value": "http://bit.ly/sbi-pan-upd",
        "threat_category": "FAKE_KYC_ACCOUNT_BLOCK_THREAT",
        "risk_level": "CRITICAL",
        "description": "Phishing shortlink leading to fake SBI YONO credential harvester.",
        "source": "CERT-In Cyber Advisory"
    },
    {
        "indicator_type": "URL",
        "indicator_value": "http://kbc-jio-lottery2026.top",
        "threat_category": "PHISHING_PAYMENT_LINK",
        "risk_level": "CRITICAL",
        "description": "Fraudulent lottery portal demanding advance registration fee via UPI.",
        "source": "Delhi Police Cyber Cell"
    },
    {
        "indicator_type": "PHONE",
        "indicator_value": "+919876543210",
        "threat_category": "FAKE_KYC_ACCOUNT_BLOCK_THREAT",
        "risk_level": "HIGH",
        "description": "Electricity power disconnection scam caller.",
        "source": "Maharashtra Cyber"
    },
    {
        "indicator_type": "PHONE",
        "indicator_value": "+918765432109",
        "threat_category": "REMOTE_ACCESS_APP_SCAM",
        "risk_level": "CRITICAL",
        "description": "Impersonating bank care desk; instructs victims to download AnyDesk.",
        "source": "I4C Cyber Threat Feed"
    },
    {
        "indicator_type": "APK",
        "indicator_value": "SBI_YONO_Update_2026.apk",
        "threat_category": "REMOTE_ACCESS_APP_SCAM",
        "risk_level": "CRITICAL",
        "description": "Trojanized APK containing SMS stealer and screen projection permissions.",
        "source": "CERT-In Alert"
    },
    {
        "indicator_type": "VPA",
        "indicator_value": "vip.telegram.tasks@paytm",
        "threat_category": "FAKE_INVESTMENT_JOB_SCAM",
        "risk_level": "CRITICAL",
        "description": "Account collecting deposits for Telegram task / YouTube like scam.",
        "source": "Bengaluru Cyber Crime"
    }
]

def seed_database_if_empty(db: Session):
    # 1. Check or Train ML model and save evaluation metrics
    existing_eval = db.query(ModelEvaluationLog).first()
    if not existing_eval:
        print("Training ML model & computing offline test set evaluation metrics...")
        metrics = MLEngine.train_and_evaluate(n_samples=5000)
        
        eval_record = ModelEvaluationLog(
            model_name=metrics["model_name"],
            train_samples=metrics["train_samples"],
            test_samples=metrics["test_samples"],
            accuracy=metrics["accuracy"],
            precision=metrics["precision"],
            recall=metrics["recall"],
            f1_score=metrics["f1_score"],
            roc_auc=metrics["roc_auc"],
            fraud_detection_rate=metrics["fraud_detection_rate"],
            false_positive_rate=metrics["false_positive_rate"],
            confusion_matrix=metrics["confusion_matrix"],
            feature_importances=metrics["feature_importances"]
        )
        db.add(eval_record)
        db.commit()

    # 2. Check Threat Intel
    if db.query(ThreatIntelligence).count() == 0:
        print("Seeding initial threat intelligence feed...")
        for item in INITIAL_THREAT_INTEL:
            ti = ThreatIntelligence(
                indicator_type=item["indicator_type"],
                indicator_value=item["indicator_value"],
                threat_category=item["threat_category"],
                risk_level=item["risk_level"],
                description=item["description"],
                source=item["source"]
            )
            db.add(ti)
        db.commit()

    # 3. Check Transactions
    if db.query(TransactionRecord).count() == 0:
        print("Seeding initial live demo transactions database...")
        # Generate 150 realistic transactions spanning past 7 days
        synthetic_df = generate_synthetic_transactions(n_samples=180)
        now = datetime.datetime.utcnow()

        threat_vpas = {item["indicator_value"].lower() for item in INITIAL_THREAT_INTEL if item["indicator_type"] == "VPA"}

        for idx, row in synthetic_df.iterrows():
            time_offset_hours = random.randint(1, 168)  # Last 7 days
            tx_time = now - datetime.timedelta(hours=time_offset_hours, minutes=random.randint(0, 59))
            
            # Predict with MLEngine
            from app.models.schemas import TransactionScanRequest, DeviceRiskSignals
            req = TransactionScanRequest(
                sender_vpa=row["sender_vpa"],
                payee_vpa=row["payee_vpa"],
                payee_name=row["payee_name"],
                amount=float(row["amount"]),
                channel=row["channel"],
                note=str(row["note"]) if pd.notna(row["note"]) else None,
                payee_account_age_days=int(row["payee_account_age_days"]),
                payee_velocity_1h=int(row["payee_velocity_1h"]),
                device_signals=DeviceRiskSignals(
                    remote_access_app_detected=bool(row["remote_access_detected"]),
                    screen_sharing_active=bool(row["screen_sharing_active"]),
                    call_in_progress=bool(row["call_in_progress"]),
                    is_new_device=bool(row["is_new_device"]),
                    is_rooted_or_jailbroken=bool(row["is_rooted"]),
                    ip_vpn_or_proxy=bool(row["is_vpn"])
                )
            )

            res = MLEngine.predict_request(req, threat_vpas=threat_vpas)

            record = TransactionRecord(
                id=f"TXN-{uuid.uuid4().hex[:10].upper()}",
                sender_vpa=row["sender_vpa"],
                payee_vpa=row["payee_vpa"],
                payee_name=row["payee_name"],
                amount=float(row["amount"]),
                channel=row["channel"],
                note=row["note"] if pd.notna(row["note"]) else None,
                timestamp=tx_time,
                risk_score=res["risk_score"],
                risk_tier=res["risk_tier"],
                scam_category=res["scam_category"],
                is_flagged=res["is_flagged"],
                recommended_action=res["recommended_action"],
                explanation_summary=res["explanation_summary"],
                feature_breakdown=res["risk_factors"],
                rules_triggered=res["rules_triggered"],
                device_signals=res["device_signals"],
                prevention_steps=res["prevention_steps"],
                ground_truth_fraud=bool(row["is_fraud"]),
                ground_truth_category=row["scam_category"]
            )
            db.add(record)

        db.commit()
        print("Database seeding completed successfully.")

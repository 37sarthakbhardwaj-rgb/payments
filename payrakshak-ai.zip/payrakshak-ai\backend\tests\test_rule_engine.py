import pytest
from app.models.schemas import TransactionScanRequest, DeviceRiskSignals
from app.services.rule_engine import RuleEngine

def test_collect_refund_scam_detection():
    req = TransactionScanRequest(
        sender_vpa="victim@okhdfcbank",
        payee_vpa="refund.desk@ybl",
        payee_name="Fast Order Refund",
        amount=4999.0,
        channel="COLLECT_REQUEST",
        note="Approve to receive your order refund",
        payee_account_age_days=3,
        payee_velocity_1h=15
    )
    penalty, hits, factors, category, steps = RuleEngine.evaluate(req)
    assert penalty >= 50.0
    assert category == "FAKE_COLLECT_REFUND_SCAM"
    assert any("COLLECT" in h.rule_code for h in hits)
    assert any("DECLINE" in s for s in steps)

def test_remote_access_scam_detection():
    req = TransactionScanRequest(
        sender_vpa="user@okaxis",
        payee_vpa="sbi.support@ybl",
        payee_name="SBI Support Helpline",
        amount=1.0,
        channel="COLLECT_REQUEST",
        note="Verification fee",
        device_signals=DeviceRiskSignals(
            remote_access_app_detected=True,
            screen_sharing_active=True,
            call_in_progress=True
        )
    )
    penalty, hits, factors, category, steps = RuleEngine.evaluate(req)
    assert penalty >= 60.0
    assert category == "REMOTE_ACCESS_APP_SCAM"
    assert any("REMOTE_DESKTOP" in h.rule_code for h in hits)

def test_safe_transaction_detection():
    req = TransactionScanRequest(
        sender_vpa="customer@okaxis",
        payee_vpa="dmart.groceries@axisbank",
        payee_name="DMart Supermarket",
        amount=1200.0,
        channel="STATIC_QR",
        note="Grocery items",
        payee_account_age_days=600,
        payee_velocity_1h=2,
        device_signals=DeviceRiskSignals()
    )
    penalty, hits, factors, category, steps = RuleEngine.evaluate(req)
    assert penalty == 0.0
    assert category == "NORMAL"

import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, JSON
from app.core.database import Base

class TransactionRecord(Base):
    __tablename__ = "transactions"

    id = Column(String(64), primary_key=True, index=True)
    sender_vpa = Column(String(128), index=True)
    payee_vpa = Column(String(128), index=True)
    payee_name = Column(String(128))
    amount = Column(Float, nullable=False)
    channel = Column(String(64))  # COLLECT_REQUEST, STATIC_QR, DYNAMIC_QR, INTENT, PAYMENT_LINK, NETBANKING
    note = Column(String(256), nullable=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow, index=True)
    
    # AI Risk & Decision outputs
    risk_score = Column(Float, nullable=False)  # 0 to 100
    risk_tier = Column(String(32), nullable=False)  # SAFE, LOW, MODERATE, HIGH, CRITICAL
    scam_category = Column(String(128), nullable=True)  # One of the 7 creative fraud categories or NORMAL
    is_flagged = Column(Boolean, default=False, index=True)
    recommended_action = Column(String(64))  # ALLOW, WARN_VERIFY, CHALLENGE_PIN, BLOCK_TRANSACTION
    
    # Deep explainability
    explanation_summary = Column(Text, nullable=True)
    feature_breakdown = Column(JSON, nullable=True)  # Dict of factors and weights
    rules_triggered = Column(JSON, nullable=True)     # List of rule codes and descriptions
    device_signals = Column(JSON, nullable=True)      # Device risk indicators captured
    prevention_steps = Column(JSON, nullable=True)    # Guidance actions for user
    
    # Ground truth (for synthetic test sets & accuracy tracking)
    ground_truth_fraud = Column(Boolean, nullable=True)
    ground_truth_category = Column(String(128), nullable=True)

class MessageScanRecord(Base):
    __tablename__ = "message_scans"

    id = Column(String(64), primary_key=True, index=True)
    raw_text = Column(Text, nullable=False)
    channel_type = Column(String(32), default="SMS")  # SMS, WHATSAPP, TELEGRAM, EMAIL
    risk_score = Column(Float, nullable=False)
    risk_tier = Column(String(32), nullable=False)
    detected_category = Column(String(128), nullable=True)
    is_malicious = Column(Boolean, default=False)
    
    # Extracted artifacts
    extracted_urls = Column(JSON, nullable=True)
    extracted_phones = Column(JSON, nullable=True)
    extracted_vpas = Column(JSON, nullable=True)
    extracted_apk_names = Column(JSON, nullable=True)
    suspicious_tokens = Column(JSON, nullable=True)
    
    explanation = Column(Text, nullable=True)
    recommended_action = Column(String(64))
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class ThreatIntelligence(Base):
    __tablename__ = "threat_intel"

    id = Column(Integer, primary_key=True, autoincrement=True)
    indicator_type = Column(String(32), index=True)  # VPA, URL, PHONE, APK, MODUS_OPERANDI
    indicator_value = Column(String(256), index=True)
    threat_category = Column(String(128))
    risk_level = Column(String(32), default="CRITICAL")
    description = Column(Text)
    source = Column(String(64), default="I4C / 1930 Cyber Cell")
    is_active = Column(Boolean, default=True)
    reported_date = Column(DateTime, default=datetime.datetime.utcnow)

class ModelEvaluationLog(Base):
    __tablename__ = "model_evaluations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    model_name = Column(String(64), default="PayRakshak-Ensemble-v1")
    trained_at = Column(DateTime, default=datetime.datetime.utcnow)
    train_samples = Column(Integer)
    test_samples = Column(Integer)
    accuracy = Column(Float)
    precision = Column(Float)
    recall = Column(Float)
    f1_score = Column(Float)
    roc_auc = Column(Float)
    fraud_detection_rate = Column(Float)  # Sensitivity / Recall on fraud class
    false_positive_rate = Column(Float)   # FPR = FP / (FP + TN)
    confusion_matrix = Column(JSON)      # [[TN, FP], [FN, TP]]
    feature_importances = Column(JSON)   # Feature names and weights
    is_active = Column(Boolean, default=True)

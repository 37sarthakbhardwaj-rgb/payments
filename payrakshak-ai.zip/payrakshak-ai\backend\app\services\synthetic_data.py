import random
import numpy as np
import pandas as pd
from typing import Tuple, List, Dict, Any

# Seed for reproducible synthetic dataset
np.random.seed(42)
random.seed(42)

LEGITIMATE_MERCHANTS = [
    ("Swiggy Delivery", "swiggy@icici"),
    ("Zomato Online", "zomato@hdfcbank"),
    ("DMart Supermarket", "dmart.retail@axisbank"),
    ("Reliance Retail", "relianceretail@sbi"),
    ("Uber India", "uber.payments@okhdfcbank"),
    ("Ola Cabs", "olacabs@paytm"),
    ("Amazon Pay Merchant", "amazonpay@ybl"),
    ("Flipkart Internet", "flipkart@axl"),
    ("BESCOM Electricity", "bescom.bills@sbi"),
    ("Tata Sky DTH", "tataplay@okaxis"),
    ("Airtel Postpaid", "airtel.bill@airtel"),
    ("Apollo Pharmacy", "apollopharmacy@icici"),
    ("Local Kirana Store", "ramesh.groceries@paytm"),
    ("Rahul Friend P2P", "rahul.gupta@okhdfcbank"),
    ("Priya Sharma", "priyasharma23@oksbi")
]

SCAM_PAYEES = {
    "FAKE_COLLECT_REFUND_SCAM": [
        ("OLX Buyer Verification", "olx.buyer.pay@ybl"),
        ("PhonePe Reward Claim", "phonepe.cashback99@axl"),
        ("GooglePay Refund Desk", "gpay.refund.portal@paytm"),
        ("Amazon Delivery Refund", "amazon.support.refund@okhdfcbank"),
    ],
    "QR_CODE_PAYMENT_SCAM": [
        ("Lucky Draw QR Payee", "kbc.lottery.qr@paytm"),
        ("Mega Cashback Scan Desk", "cashback.qr.claim@ybl"),
        ("Winner Reward UPI", "winner.prize.scan@okhdfcbank")
    ],
    "REMOTE_ACCESS_APP_SCAM": [
        ("SBI Senior Helpline Officer", "sbi.helpdesk.agent@ybl"),
        ("Customer Care Senior Executive", "care.desk.officer@axl"),
        ("Airtel Tech Support Fee", "airtel.tech.fee@paytm")
    ],
    "FAKE_INVESTMENT_JOB_SCAM": [
        ("Telegram VIP Tasks", "vip.telegram.tasks@paytm"),
        ("Hotel Rating Commission Dep", "merchant.rating.deposit@ybl"),
        ("Crypto Arbitrage Deposit", "crypto.growth.trade@okhdfcbank"),
        ("Daily Wealth Task Fund", "daily.wealth.task@axl")
    ],
    "MULE_ACCOUNT_PATTERNS": [
        ("Rajesh New Account", "rajesh.transient77@paytm"),
        ("Amit Mule Beneficiary", "amit.kumar.fast99@ybl"),
        ("Fresh Digital Wallet", "quick.transfer108@axl")
    ],
    "PHISHING_PAYMENT_LINK": [
        ("Income Tax Refund Link", "incometax.refund.portal@paytm"),
        ("KYC Verification Gateway", "kyc.online.verify@ybl"),
        ("Electricity Bill Reactivate", "electricity.emergency.bill@okhdfcbank")
    ],
    "FAKE_KYC_ACCOUNT_BLOCK_THREAT": [
        ("YONO KYC Compliance", "yono.compliance.desk@sbi"),
        ("HDFC Netbanking Reactivate", "hdfc.security.update@ybl"),
        ("Aadhaar PAN Link Fee", "pan.link.authority@paytm")
    ]
}

def generate_synthetic_transactions(n_samples: int = 6000) -> pd.DataFrame:
    """
    Generates a realistic synthetic dataset of Indian digital payment transactions (UPI)
    with balanced representations of benign patterns and 7 creative fraud archetypes.
    """
    records: List[Dict[str, Any]] = []

    # Distribution: ~82% legitimate, ~18% creative fraud
    n_fraud = int(n_samples * 0.18)
    n_normal = n_samples - n_fraud

    # 1. Normal transactions
    for i in range(n_normal):
        merchant_name, payee_vpa = random.choice(LEGITIMATE_MERCHANTS)
        sender_vpa = f"user_{random.randint(1000, 9999)}@okaxis"
        channel = random.choices(
            ["INTENT", "STATIC_QR", "DYNAMIC_QR", "COLLECT_REQUEST", "NETBANKING", "PAYMENT_LINK"],
            weights=[0.45, 0.30, 0.15, 0.05, 0.03, 0.02]
        )[0]
        
        # Normal amount distributions: log-normal around ₹350, occasionally larger
        if random.random() < 0.85:
            amount = round(float(np.random.exponential(scale=650) + 20), 2)
            amount = min(amount, 8000.0)
        else:
            amount = round(float(random.uniform(5000, 45000)), 2)

        hour = int(random.choices(
            list(range(24)),
            weights=[1, 1, 1, 1, 1, 2, 4, 6, 8, 9, 8, 9, 10, 9, 8, 9, 10, 11, 12, 10, 8, 6, 4, 2]
        )[0])

        payee_account_age_days = random.randint(45, 1200)
        payee_velocity_1h = random.choices([0, 1, 2, 3, 4], weights=[0.5, 0.3, 0.12, 0.06, 0.02])[0]
        
        # Device signals (benign)
        remote_app = False
        screen_sharing = False
        call_in_progress = random.random() < 0.03  # Rarely on phone during payment
        is_new_device = random.random() < 0.04
        is_rooted = random.random() < 0.01
        is_vpn = random.random() < 0.02

        note = random.choice(["Groceries", "Dinner", "Lunch", "Ride fare", "Bill payment", "", "Monthly share", "Shopping"])

        records.append({
            "sender_vpa": sender_vpa,
            "payee_vpa": payee_vpa,
            "payee_name": merchant_name,
            "amount": amount,
            "channel": channel,
            "note": note,
            "hour": hour,
            "payee_account_age_days": payee_account_age_days,
            "payee_velocity_1h": payee_velocity_1h,
            "remote_access_detected": int(remote_app),
            "screen_sharing_active": int(screen_sharing),
            "call_in_progress": int(call_in_progress),
            "is_new_device": int(is_new_device),
            "is_rooted": int(is_rooted),
            "is_vpn": int(is_vpn),
            "is_fraud": 0,
            "scam_category": "NORMAL"
        })

    # 2. Creative Frauds across 7 archetypes
    categories = list(SCAM_PAYEES.keys())
    per_category = n_fraud // len(categories)

    for cat in categories:
        for _ in range(per_category):
            sender_vpa = f"victim_{random.randint(1000, 9999)}@okicici"
            payee_name, payee_vpa = random.choice(SCAM_PAYEES[cat])
            
            # Specific traits per creative scam
            if cat == "FAKE_COLLECT_REFUND_SCAM":
                channel = "COLLECT_REQUEST"
                amount = round(random.choice([1999.0, 4999.0, 9999.0, 14999.0, 24999.0]), 2)
                note = random.choice([
                    "Approve to receive your order refund",
                    "OLX buyer payment: enter UPI PIN to receive money",
                    "Swiggy cash refund credited",
                    "Click to accept Rs 5000 cashback"
                ])
                remote_app = False
                screen_sharing = False
                call_in_progress = random.random() < 0.45
                payee_age = random.randint(1, 15)
                velocity = random.randint(5, 25)

            elif cat == "QR_CODE_PAYMENT_SCAM":
                channel = random.choice(["STATIC_QR", "DYNAMIC_QR"])
                amount = round(random.choice([2500.0, 5000.0, 10000.0, 15000.0]), 2)
                note = random.choice([
                    "Scan QR to claim lottery prize",
                    "Reward cash deposit QR",
                    "Scan to receive buyer payment"
                ])
                remote_app = False
                screen_sharing = False
                call_in_progress = random.random() < 0.3
                payee_age = random.randint(2, 20)
                velocity = random.randint(8, 30)

            elif cat == "REMOTE_ACCESS_APP_SCAM":
                channel = random.choice(["COLLECT_REQUEST", "INTENT", "PAYMENT_LINK"])
                amount = round(random.choice([1.0, 10.0, 4999.0, 19999.0, 49999.0]), 2)
                note = random.choice([
                    "Test verification fee for refund",
                    "AnyDesk technical assistance verification",
                    "Reversal fee authorization"
                ])
                remote_app = True
                screen_sharing = True
                call_in_progress = True
                payee_age = random.randint(1, 10)
                velocity = random.randint(4, 15)

            elif cat == "FAKE_INVESTMENT_JOB_SCAM":
                channel = random.choice(["INTENT", "PAYMENT_LINK"])
                amount = round(random.choice([3000.0, 8000.0, 25000.0, 50000.0, 100000.0]), 2)
                note = random.choice([
                    "VIP Telegram Task Level 2 Deposit",
                    "YouTube Rating Commission Upgrade",
                    "Crypto Arbitrage Fast Growth",
                    "Part-time job security deposit"
                ])
                remote_app = False
                screen_sharing = False
                call_in_progress = False
                payee_age = random.randint(3, 14)
                velocity = random.randint(15, 50)

            elif cat == "MULE_ACCOUNT_PATTERNS":
                channel = random.choice(["INTENT", "DYNAMIC_QR"])
                amount = round(random.choice([9500.0, 19900.0, 49000.0, 89000.0]), 2)
                note = "Fund transfer"
                remote_app = False
                screen_sharing = False
                call_in_progress = False
                payee_age = random.randint(1, 6)
                velocity = random.randint(25, 80)

            elif cat == "PHISHING_PAYMENT_LINK":
                channel = "PAYMENT_LINK"
                amount = round(random.choice([499.0, 1250.0, 3999.0, 8500.0]), 2)
                note = random.choice([
                    "Pending KYC payment link",
                    "Electricity bill disconnection emergency pay",
                    "Claim Income Tax refund processing fee"
                ])
                remote_app = False
                screen_sharing = False
                call_in_progress = random.random() < 0.2
                payee_age = random.randint(1, 12)
                velocity = random.randint(10, 35)

            elif cat == "FAKE_KYC_ACCOUNT_BLOCK_THREAT":
                channel = random.choice(["PAYMENT_LINK", "COLLECT_REQUEST"])
                amount = round(random.choice([100.0, 500.0, 1999.0, 9999.0]), 2)
                note = random.choice([
                    "Urgent PAN KYC update fee",
                    "SBI account unblock charge",
                    "Aadhaar verification mandate"
                ])
                remote_app = random.random() < 0.3
                screen_sharing = random.random() < 0.2
                call_in_progress = random.random() < 0.4
                payee_age = random.randint(1, 8)
                velocity = random.randint(8, 28)

            hour = random.randint(0, 23)
            is_new_device = random.random() < 0.25
            is_rooted = random.random() < 0.15
            is_vpn = random.random() < 0.3

            records.append({
                "sender_vpa": sender_vpa,
                "payee_vpa": payee_vpa,
                "payee_name": payee_name,
                "amount": amount,
                "channel": channel,
                "note": note,
                "hour": hour,
                "payee_account_age_days": payee_age,
                "payee_velocity_1h": velocity,
                "remote_access_detected": int(remote_app),
                "screen_sharing_active": int(screen_sharing),
                "call_in_progress": int(call_in_progress),
                "is_new_device": int(is_new_device),
                "is_rooted": int(is_rooted),
                "is_vpn": int(is_vpn),
                "is_fraud": 1,
                "scam_category": cat
            })

    # Shuffle the dataset
    df = pd.DataFrame(records).sample(frac=1.0, random_state=42).reset_index(drop=True)
    return df

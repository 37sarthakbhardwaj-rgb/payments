import React from 'react';
import { ShieldCheck, AlertTriangle, AlertOctagon, Info, ShieldAlert } from 'lucide-react';

interface Props {
  tier: 'SAFE' | 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL' | string;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
}

export const RiskBadge: React.FC<Props> = ({ tier, size = 'md', showIcon = true }) => {
  const normalizedTier = tier?.toUpperCase() || 'SAFE';

  let config = {
    bg: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400',
    icon: ShieldCheck,
    label: 'SAFE',
    dot: 'bg-emerald-400',
  };

  switch (normalizedTier) {
    case 'LOW':
      config = {
        bg: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400',
        icon: Info,
        label: 'LOW RISK',
        dot: 'bg-cyan-400',
      };
      break;
    case 'MODERATE':
      config = {
        bg: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
        icon: AlertTriangle,
        label: 'MODERATE',
        dot: 'bg-amber-400',
      };
      break;
    case 'HIGH':
      config = {
        bg: 'bg-orange-500/10 border-orange-500/30 text-orange-400',
        icon: AlertTriangle,
        label: 'HIGH RISK',
        dot: 'bg-orange-400',
      };
      break;
    case 'CRITICAL':
      config = {
        bg: 'bg-red-500/10 border-red-500/30 text-red-400 cyber-glow-red animate-pulse-subtle',
        icon: ShieldAlert,
        label: 'CRITICAL',
        dot: 'bg-red-500',
      };
      break;
  }

  const Icon = config.icon;

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3.5 py-1.5 gap-2 font-semibold',
  }[size];

  const iconSizes = {
    sm: 12,
    md: 14,
    lg: 16,
  }[size];

  return (
    <span className={`inline-flex items-center rounded-full border font-mono tracking-wider ${config.bg} ${sizeClasses}`}>
      {showIcon && <Icon size={iconSizes} />}
      <span className="font-semibold">{config.label}</span>
    </span>
  );
};

import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  ArrowRight,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Play,
  RotateCcw,
  Zap,
  Users,
  Smartphone,
  QrCode,
  ArrowDownLeft,
  Briefcase,
  ZapOff
} from 'lucide-react';
import { api } from '../services/api';
import { ScenarioItem } from '../types';

interface Props {
  onSelectScenarioForScanner: (scen: ScenarioItem) => void;
}

export const FraudSimulations: React.FC<Props> = ({ onSelectScenarioForScanner }) => {
  const [scenarios, setScenarios] = useState<ScenarioItem[]>([]);
  const [selectedScen, setSelectedScen] = useState<ScenarioItem | null>(null);

  useEffect(() => {
    api.getScenarios().then((data) => {
      setScenarios(data);
      if (data.length > 0) setSelectedScen(data[0]);
    }).catch(console.error);
  }, []);

  const getIcon = (name: string) => {
    switch (name) {
      case 'ArrowDownLeft':
        return ArrowDownLeft;
      case 'MonitorSmartphone':
        return Smartphone;
      case 'QrCode':
        return QrCode;
      case 'Briefcase':
        return Briefcase;
      case 'Users':
        return Users;
      case 'ZapOff':
        return ZapOff;
      default:
        return CheckCircle2;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 rounded-2xl bg-navy-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-cyan-400" />
            <h1 className="text-xl font-bold text-white tracking-tight">
              Interactive Creative Fraud Simulator
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-400 max-w-xl">
            Explore the 7 creative fraud archetypes identified in CCG-AI02. Inspect the fraudster's modus operandi, compare outcomes with and without AI, and load scenarios directly into the scanner.
          </p>
        </div>

        <div className="px-3 py-1.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-xs font-mono text-cyan-400">
          7 Creative Archetypes + Normal Baseline
        </div>
      </div>

      {/* Grid of Scenarios */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {scenarios.map((scen, idx) => {
          const isSelected = selectedScen?.id === scen.id;
          const isNormal = scen.scam_category === 'NORMAL';

          return (
            <div
              key={scen.id}
              onClick={() => setSelectedScen(scen)}
              className={`p-5 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-navy-850 border-cyan-400 shadow-lg shadow-cyan-500/10'
                  : 'bg-navy-900/90 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold ${
                      isNormal
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-red-500/20 text-red-300 border border-red-500/30'
                    }`}
                  >
                    {isNormal ? 'BENIGN BASELINE' : `SCAM ARCHETYPE #${idx + 1}`}
                  </span>
                  <span className="text-xs font-mono font-bold text-cyan-400">
                    ₹{scen.sample_request.amount.toLocaleString()}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white tracking-tight mb-1">{scen.title}</h3>
                <p className="text-xs font-mono text-cyan-400 mb-2">{scen.subtitle}</p>
                <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                  {scen.context_story}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[11px] font-mono text-slate-500">{scen.sample_request.channel}</span>
                <span className="text-xs font-mono text-cyan-400 flex items-center space-x-1 hover:underline">
                  <span>Inspect</span>
                  <ArrowRight className="h-3 w-3" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Scenario Deep-Dive Card */}
      {selectedScen && (
        <div className="rounded-2xl bg-navy-900 border border-cyan-500/30 p-6 shadow-2xl space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {selectedScen.scam_category}
                </span>
                <span className="text-xs font-mono text-slate-400">Channel: {selectedScen.sample_request.channel}</span>
              </div>
              <h2 className="mt-2 text-xl font-bold text-white tracking-tight">
                {selectedScen.title}
              </h2>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl">{selectedScen.context_story}</p>
            </div>

            <button
              onClick={() => onSelectScenarioForScanner(selectedScen)}
              className="py-2.5 px-5 rounded-xl font-bold font-mono text-xs text-navy-950 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 shadow-lg shadow-cyan-500/25 flex items-center space-x-2 transition-all self-start md:self-auto shrink-0"
            >
              <Play className="h-3.5 w-3.5 fill-navy-950" />
              <span>TEST IN TRANSACTION SCANNER</span>
            </button>
          </div>

          {/* Modus Operandi & Comparative Outcome */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Modus Operandi */}
            <div className="p-4 rounded-xl bg-navy-950 border border-slate-800">
              <span className="text-xs font-mono uppercase text-amber-400 font-semibold block mb-2">
                🕵️ Fraudster's Modus Operandi
              </span>
              <p className="text-xs text-slate-300 leading-relaxed">
                {selectedScen.modus_operandi}
              </p>
            </div>

            {/* Without AI vs With AI */}
            <div className="p-4 rounded-xl bg-navy-950 border border-slate-800 space-y-3">
              <div>
                <span className="text-xs font-mono uppercase text-red-400 font-semibold block mb-1">
                  ❌ Without PayRakshak AI (Standard UPI Flow)
                </span>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {selectedScen.what_would_happen_without_ai}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800/80">
                <span className="text-xs font-mono uppercase text-emerald-400 font-semibold block mb-1">
                  🛡️ With PayRakshak AI Interception
                </span>
                <p className="text-xs text-emerald-300/90 leading-relaxed">
                  Engine intercepts the payment before PIN entry. Detects {selectedScen.scam_category}, challenges transaction, displays plain-language warning, and blocks unauthorized account drainage.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

function CheckCircle2(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}

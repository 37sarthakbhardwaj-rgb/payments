import React, { useState } from 'react';
import {
  MessageSquareWarning,
  Sparkles,
  Link2,
  Phone,
  FileCode,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  Send,
  HelpCircle,
  Copy
} from 'lucide-react';
import { api } from '../services/api';
import { RiskBadge } from '../components/RiskBadge';
import { MessageScanResponse } from '../types';

const SAMPLE_TEMPLATES = [
  {
    label: '⚡ Electricity Blackout Threat',
    category: 'FAKE_KYC_ACCOUNT_BLOCK_THREAT',
    text: 'Electricity Power Alert: Your electricity power supply will be disconnected tonight at 9:30 PM due to unpaid previous month bill. Call officer immediately at 9876543210 or click http://bescom-bill-update.online to avoid blackout.',
  },
  {
    label: '🏛️ SBI YONO KYC Suspended Link',
    category: 'FAKE_KYC_ACCOUNT_BLOCK_THREAT',
    text: 'Dear SBI Customer, your YONO account is suspended due to expired PAN KYC. Update PAN card immediately at http://bit.ly/sbi-pan-upd within 24 hours to avoid permanent account block.',
  },
  {
    label: '🛋️ OLX Enter PIN to Receive',
    category: 'FAKE_COLLECT_REFUND_SCAM',
    text: 'OLX Buyer Message: I have sent a UPI collect request of Rs 15,000 for your dining table. Please click approve and enter your UPI PIN to receive the money in your bank account.',
  },
  {
    label: '💼 Telegram VIP Job Scam',
    category: 'FAKE_INVESTMENT_JOB_SCAM',
    text: 'Work from home part-time: Earn Rs 3,000 to Rs 8,000 daily by rating hotels and liking YouTube videos. Deposit Rs 1,000 to start tasks. Join Telegram @VIP_Task_Growth or contact HR on WhatsApp 9988776655.',
  },
  {
    label: '🛠️ AnyDesk Tech Support APK',
    category: 'REMOTE_ACCESS_APP_SCAM',
    text: 'Airtel Customer Helpline: For network speed issue, please download QuickSupport app from http://airtel-helpdesk-agent.site/QuickSupport.apk and share code with our senior executive.',
  },
  {
    label: '✅ Normal Bank Transaction OTP',
    category: 'LEGITIMATE',
    text: 'Your OTP for ICICI Bank NetBanking login is 839201. Valid for 10 minutes. Do not share OTP with anyone, ICICI Bank never asks for OTP or passwords.',
  },
];

export const MessageScanner: React.FC = () => {
  const [text, setText] = useState<string>(SAMPLE_TEMPLATES[0].text);
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<MessageScanResponse | null>(null);

  const handleScan = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!text.trim()) return;

    setLoading(true);
    try {
      const res = await api.scanMessage(text, 'SMS');
      setResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 rounded-2xl bg-navy-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <MessageSquareWarning className="h-5 w-5 text-cyan-400" />
            <h1 className="text-xl font-bold text-white tracking-tight">
              Phishing SMS & Malicious Link Scanner
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-400 max-w-xl">
            Analyzes raw SMS, WhatsApp, and Telegram payment messages, identifies phishing shorteners, trojanized APK downloads, and panic-inducing social engineering tactics.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-navy-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono text-cyan-300">
          <Sparkles className="h-4 w-4 text-cyan-400" />
          <span>NLP + Threat Intel Active</span>
        </div>
      </div>

      {/* Preset Buttons */}
      <div className="bg-navy-900/60 p-4 rounded-xl border border-slate-800/80">
        <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-2">
          Load Sample Scams & Legitimate Messages:
        </span>
        <div className="flex flex-wrap gap-2">
          {SAMPLE_TEMPLATES.map((tmpl, idx) => (
            <button
              key={idx}
              onClick={() => setText(tmpl.text)}
              className="px-3 py-1.5 rounded-lg bg-navy-950 border border-slate-700/60 hover:border-cyan-500/40 text-xs font-mono text-slate-300 hover:text-white transition-all"
            >
              {tmpl.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Scanner Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Input Textarea */}
        <div className="lg:col-span-6 space-y-4">
          <form onSubmit={handleScan} className="bg-navy-900/90 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-xl">
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-mono uppercase text-slate-300 font-semibold">
                  Raw Message / SMS Content
                </label>
                <span className="text-[11px] font-mono text-slate-500">
                  {text.length} characters
                </span>
              </div>
              <textarea
                rows={6}
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste the suspicious SMS, WhatsApp message, or payment URL here..."
                className="w-full bg-navy-950 border border-slate-700/80 rounded-xl p-3 text-xs font-mono text-white placeholder-slate-600 focus:border-cyan-400 focus:outline-none leading-relaxed"
                required
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => setText('')}
                className="text-xs font-mono text-slate-400 hover:text-slate-200"
              >
                Clear
              </button>

              <button
                type="submit"
                disabled={loading || !text.trim()}
                className="py-2.5 px-6 rounded-xl font-bold font-mono text-xs text-navy-950 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 shadow-lg shadow-cyan-500/25 flex items-center space-x-2 transition-all disabled:opacity-50"
              >
                {loading ? (
                  <span>Scanning Message...</span>
                ) : (
                  <>
                    <Send className="h-3.5 w-3.5 fill-navy-950" />
                    <span>ANALYZE THREAT SIGNATURES</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Right: Scan Results */}
        <div className="lg:col-span-6 space-y-4">
          {result ? (
            <div className="bg-navy-900/90 rounded-2xl border border-slate-800 p-5 space-y-5 shadow-2xl">
              {/* Header */}
              <div className="flex items-start justify-between border-b border-slate-800 pb-4">
                <div>
                  <span className="text-[10px] font-mono uppercase text-slate-500">
                    NLP Threat Analysis
                  </span>
                  <div className="flex items-center space-x-3 mt-1">
                    <RiskBadge tier={result.risk_tier} size="lg" />
                    <span className="text-xs font-mono text-cyan-400 font-bold">
                      {result.detected_category}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] font-mono uppercase text-slate-500 block">
                    Threat Score
                  </span>
                  <span
                    className={`text-3xl font-extrabold font-mono ${
                      result.risk_score >= 70
                        ? 'text-red-400'
                        : result.risk_score >= 35
                        ? 'text-amber-400'
                        : 'text-emerald-400'
                    }`}
                  >
                    {result.risk_score}
                    <span className="text-sm font-normal text-slate-500">/100</span>
                  </span>
                </div>
              </div>

              {/* Action Recommendation */}
              <div
                className={`p-3.5 rounded-xl border text-xs font-mono flex items-center justify-between ${
                  result.is_malicious
                    ? 'bg-red-500/10 border-red-500/30 text-red-300'
                    : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <ShieldAlert className="h-4 w-4 shrink-0" />
                  <span>
                    Action: <strong>{result.recommended_action}</strong>
                  </span>
                </div>
                <span className="text-[11px] font-bold">
                  {result.is_malicious ? 'MALICIOUS DETECTED' : 'LEGITIMATE'}
                </span>
              </div>

              {/* Extracted Artifacts / Indicators */}
              <div className="space-y-3 pt-1">
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  Extracted Indicators of Compromise (IoCs)
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                  {/* Extracted URLs */}
                  <div className="p-3 rounded-lg bg-navy-950 border border-slate-800">
                    <div className="flex items-center space-x-1.5 text-slate-400 text-[11px] mb-1">
                      <Link2 className="h-3.5 w-3.5 text-cyan-400" />
                      <span>Extracted URLs ({result.extracted_entities.urls.length})</span>
                    </div>
                    {result.extracted_entities.urls.length > 0 ? (
                      <div className="space-y-1">
                        {result.extracted_entities.urls.map((u, i) => (
                          <span
                            key={i}
                            className="block text-red-400 font-mono text-[11px] truncate bg-red-950/40 px-2 py-0.5 rounded border border-red-900/60"
                          >
                            {u}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-slate-500 text-[11px]">No external URLs found</span>
                    )}
                  </div>

                  {/* Extracted Phone Numbers */}
                  <div className="p-3 rounded-lg bg-navy-950 border border-slate-800">
                    <div className="flex items-center space-x-1.5 text-slate-400 text-[11px] mb-1">
                      <Phone className="h-3.5 w-3.5 text-amber-400" />
                      <span>Extracted Numbers ({result.extracted_entities.phones.length})</span>
                    </div>
                    {result.extracted_entities.phones.length > 0 ? (
                      <div className="space-y-1">
                        {result.extracted_entities.phones.map((p, i) => (
                          <span
                            key={i}
                            className="block text-amber-300 font-mono text-[11px] bg-amber-950/40 px-2 py-0.5 rounded border border-amber-900/60"
                          >
                            {p}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-slate-500 text-[11px]">No phone numbers found</span>
                    )}
                  </div>
                </div>

                {/* Extracted Suspicious Phrases */}
                {result.extracted_entities.suspicious_phrases.length > 0 && (
                  <div className="p-3 rounded-lg bg-navy-950 border border-slate-800">
                    <span className="text-[11px] font-mono text-slate-400 block mb-1.5">
                      Social Engineering Urgency Triggers:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {result.extracted_entities.suspicious_phrases.map((phrase, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded bg-red-500/20 text-red-300 text-[11px] font-mono border border-red-500/30"
                        >
                          "{phrase}"
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Explanation Summary */}
              <div className="p-4 rounded-xl bg-navy-950 border border-slate-800 text-xs">
                <span className="font-semibold text-white block mb-1">Detailed Findings:</span>
                <p className="text-slate-300 leading-relaxed">{result.explanation}</p>
              </div>

              {/* National Cyber Helpline Advisory */}
              <div className="p-3.5 rounded-xl bg-cyan-950/20 border border-cyan-500/30 text-xs text-slate-300 font-mono">
                <span className="text-cyan-400 font-bold block mb-1">🚨 Cyber Advisory:</span>
                <p>{result.cyber_cell_advisory}</p>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[380px] flex flex-col items-center justify-center p-8 rounded-2xl bg-navy-900/40 border border-dashed border-slate-800 text-center">
              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 mb-3">
                <MessageSquareWarning className="h-8 w-8" />
              </div>
              <h3 className="text-sm font-bold text-white">No Message Scanned</h3>
              <p className="mt-1 text-xs text-slate-400 max-w-sm">
                Paste message content or pick a preset scam above, then click{' '}
                <strong>ANALYZE THREAT SIGNATURES</strong>.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

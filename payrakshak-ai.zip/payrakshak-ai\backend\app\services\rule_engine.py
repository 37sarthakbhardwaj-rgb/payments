import re
from typing import List, Dict, Any, Tuple
from app.models.schemas import TransactionScanRequest, RuleHit, RiskFactor

# List of known remote access packages and keywords
REMOTE_ACCESS_APPS = ["anydesk", "teamviewer", "rustdesk", "quicksupport", "airmirror", "zoho assist", "splashtop"]

# Suspicious words indicating reversal/collect tricks
COLLECT_SCAM_KEYWORDS = [
    "refund", "cashback", "receive", "accept", "credit", "won", "prize",
    "claim", "bonus", "reward", "olx", "buyer", "reversal", "order cancel"
]

# Suspicious KYC and panic keywords
KYC_PANIC_KEYWORDS = [
    "kyc", "pan", "blocked", "suspended", "disconnected", "deactivated",
    "urgent", "immediately", "verify", "electricity", "cut off", "expire"
]

# High-risk investment and job scam keywords
INVESTMENT_JOB_KEYWORDS = [
    "telegram", "task", "youtube like", "hotel review", "crypto deposit",
    "part time", "daily income", "roi", "double money", "guaranteed profit",
    "work from home", "commission"
]

class RuleEngine:
    """
    Expert heuristic rule engine targeting India's digital payment ecosystem & UPI creative frauds:
    1. Fake collect requests and refund scams
    2. QR-code payment scams
    3. Fake customer-care numbers & remote-access app scams
    4. Fake investment and job-offer payment requests
    5. Mule-account and suspicious beneficiary patterns
    6. Phishing SMS & malicious payment links
    7. Fake KYC updates and account-blocking threats
    """

    @classmethod
    def evaluate(cls, req: TransactionScanRequest, threat_vpas: set[str] = None) -> Tuple[float, List[RuleHit], List[RiskFactor], str, List[str]]:
        rule_hits: List[RuleHit] = []
        risk_factors: List[RiskFactor] = []
        prevention_steps: List[str] = []
        penalty_score: float = 0.0
        primary_category: str = "NORMAL"

        threat_vpas = threat_vpas or set()
        channel = req.channel.upper()
        note = (req.note or "").lower()
        payee_vpa = req.payee_vpa.lower()
        payee_name = req.payee_name.lower()
        dev = req.device_signals or None

        # Check threat intelligence list
        if payee_vpa in threat_vpas:
            penalty_score += 65.0
            rule_hits.append(RuleHit(
                rule_code="THREAT_INTEL_BLACKLIST",
                category="MULE_ACCOUNT",
                title="Beneficiary Flagged in Cyber Threat Database",
                severity="CRITICAL",
                description=f"The UPI ID {req.payee_vpa} has been reported for cyber fraud to I4C / National Cyber Crime Reporting Portal."
            ))
            risk_factors.append(RiskFactor(
                factor_name="Flagged Cyber Fraud Beneficiary",
                impact_score=65.0,
                severity="CRITICAL",
                description="Beneficiary VPA exists in National Threat Intelligence Repository"
            ))

        # -----------------------------------------------------------------
        # CATEGORY 1: Fake Collect Requests and Refund Scams
        # -----------------------------------------------------------------
        is_collect = channel == "COLLECT_REQUEST"
        has_refund_claim = any(kw in note or kw in payee_name for kw in COLLECT_SCAM_KEYWORDS)

        if is_collect and has_refund_claim:
            penalty_score += 55.0
            primary_category = "FAKE_COLLECT_REFUND_SCAM"
            rule_hits.append(RuleHit(
                rule_code="UPI_COLLECT_REVERSAL_DECEPTION",
                category="FAKE_COLLECT_REFUND_SCAM",
                title="UPI PIN Inversion Scam (Collect Request Masked as Refund/Credit)",
                severity="CRITICAL",
                description="Collect request received with refund/reward notes. In UPI architecture, you NEVER enter your UPI PIN to receive money. Entering your PIN will DEBIT money from your account."
            ))
            risk_factors.append(RiskFactor(
                factor_name="Collect Request with Inward Credit Note",
                impact_score=55.0,
                severity="CRITICAL",
                description="Scammer initiated a pull-payment asking you to approve or enter PIN to receive funds"
            ))
            prevention_steps.append("DECLINE the collect request immediately. Entering your UPI PIN will send money, not receive it.")
            prevention_steps.append("Block the UPI handle on your payment app (Google Pay / PhonePe / Paytm).")

        elif is_collect and req.amount >= 2000:
            penalty_score += 25.0
            rule_hits.append(RuleHit(
                rule_code="UNSOLICITED_COLLECT_REQUEST",
                category="FAKE_COLLECT_REFUND_SCAM",
                title="Unsolicited Collect Request of Significant Amount",
                severity="HIGH",
                description="A collect request of ₹{req.amount:,.2f} was triggered. Always confirm who is requesting before approval."
            ))
            risk_factors.append(RiskFactor(
                factor_name="High-Value Collect Request",
                impact_score=25.0,
                severity="HIGH",
                description="Pull-payment initiated by external party"
            ))

        # -----------------------------------------------------------------
        # CATEGORY 2: QR-Code Payment Scams
        # -----------------------------------------------------------------
        is_qr = channel in ["STATIC_QR", "DYNAMIC_QR"]
        qr_cashback_promise = any(kw in note for kw in ["receive", "lottery", "cashback", "scan to get", "congratulations", "win"])

        if is_qr and qr_cashback_promise:
            penalty_score += 50.0
            if primary_category == "NORMAL":
                primary_category = "QR_CODE_PAYMENT_SCAM"
            rule_hits.append(RuleHit(
                rule_code="QR_SCAN_RECEIVE_DECEPTION",
                category="QR_CODE_PAYMENT_SCAM",
                title="Malicious QR Scanning Deception ('Scan to Receive')",
                severity="CRITICAL",
                description="Scanning a QR code on UPI is strictly for PAYING money out. Scammers paste malicious QR codes claiming you will receive prizes or buyer payments upon scan."
            ))
            risk_factors.append(RiskFactor(
                factor_name="QR Code Scan-to-Receive Trap",
                impact_score=50.0,
                severity="CRITICAL",
                description="QR codes can only deduct money from your account, never deposit"
            ))
            prevention_steps.append("Never scan a QR code sent over WhatsApp, SMS, or OLX to 'receive' money.")

        # -----------------------------------------------------------------
        # CATEGORY 3: Fake Customer-Care & Remote-Access App Scams
        # -----------------------------------------------------------------
        remote_app_active = dev and (dev.remote_access_app_detected or dev.screen_sharing_active)
        call_in_progress = dev and dev.call_in_progress
        impersonation = any(bank in payee_name or bank in payee_vpa for bank in ["sbi", "hdfc", "icici", "airtel", "support", "helpdesk", "care", "customer"])

        if remote_app_active and (call_in_progress or is_collect or impersonation):
            penalty_score += 65.0
            primary_category = "REMOTE_ACCESS_APP_SCAM"
            rule_hits.append(RuleHit(
                rule_code="REMOTE_DESKTOP_SCREENSHARE_DETECTED",
                category="REMOTE_ACCESS_APP_SCAM",
                title="Screen Sharing / Remote Desktop App Active During Payment",
                severity="CRITICAL",
                description="Active remote control app (e.g., AnyDesk, TeamViewer, RustDesk) or screen sharing detected while on an active call. Scammers use this to view your screen and capture OTP / UPI credentials."
            ))
            risk_factors.append(RiskFactor(
                factor_name="Active Screen Mirroring / Remote App",
                impact_score=65.0,
                severity="CRITICAL",
                description="Third party may be viewing your screen or intercepting OTPs"
            ))
            prevention_steps.append("STOP the transaction. Disconnect any screen sharing session (AnyDesk / TeamViewer / QuickSupport).")
            prevention_steps.append("Hang up the call immediately. Legitimate bank support never asks you to install remote control apps.")

        elif remote_app_active:
            penalty_score += 35.0
            rule_hits.append(RuleHit(
                rule_code="SUSPICIOUS_SCREEN_SHARE",
                category="REMOTE_ACCESS_APP_SCAM",
                title="Screen Sharing Detected in Payment Session",
                severity="HIGH",
                description="A screen capture or remote access tool is active on device during payment processing."
            ))
            risk_factors.append(RiskFactor(
                factor_name="Screen Sharing Active",
                impact_score=35.0,
                severity="HIGH",
                description="Potential privacy leakage of banking credentials"
            ))

        # -----------------------------------------------------------------
        # CATEGORY 4: Fake Investment & Job-Offer Payment Requests
        # -----------------------------------------------------------------
        is_job_crypto = any(kw in note or kw in payee_name for kw in INVESTMENT_JOB_KEYWORDS)
        if is_job_crypto:
            penalty_score += 45.0
            if primary_category == "NORMAL":
                primary_category = "FAKE_INVESTMENT_JOB_SCAM"
            rule_hits.append(RuleHit(
                rule_code="INVESTMENT_TASK_SCAM_INDICATOR",
                category="FAKE_INVESTMENT_JOB_SCAM",
                title="Work-From-Home / Telegram Task / Crypto Investment Pattern",
                severity="CRITICAL",
                description="Payment linked to task-based earnings, Telegram group referrals, or unverified crypto schemes. Fraudsters lure victims with small initial payouts then demand large deposits."
            ))
            risk_factors.append(RiskFactor(
                factor_name="Task Scam / High-Yield Scheme Marker",
                impact_score=45.0,
                severity="CRITICAL",
                description="Pre-payment required for guaranteed daily returns or job unlock"
            ))
            prevention_steps.append("Legitimate employers or rating agencies NEVER ask you to deposit money to earn commissions.")
            prevention_steps.append("Leave the Telegram/WhatsApp group and report the account to cybercrime.gov.in.")

        # -----------------------------------------------------------------
        # CATEGORY 5: Mule-Account & Suspicious Beneficiary Velocity
        # -----------------------------------------------------------------
        account_age = req.payee_account_age_days if req.payee_account_age_days is not None else 180
        velocity = req.payee_velocity_1h if req.payee_velocity_1h is not None else 1

        if account_age <= 7 and velocity >= 12:
            penalty_score += 45.0
            if primary_category == "NORMAL":
                primary_category = "MULE_ACCOUNT_PATTERNS"
            rule_hits.append(RuleHit(
                rule_code="NEW_VPA_HIGH_VELOCITY_MULE",
                category="MULE_ACCOUNT_PATTERNS",
                title="High-Velocity Fresh Beneficiary (Money Mule Signature)",
                severity="HIGH",
                description=f"Beneficiary handle was created {account_age} days ago and has processed {velocity} transactions in the last hour. This burst behavior is typical of transient money-mule accounts."
            ))
            risk_factors.append(RiskFactor(
                factor_name="Transient Mule Account Signature",
                impact_score=45.0,
                severity="HIGH",
                description="Recently registered VPA experiencing rapid abnormal transaction bursts"
            ))
            prevention_steps.append("Verify the payee's physical identity or registered merchant certificate before transferring.")

        elif account_age <= 14:
            penalty_score += 15.0
            risk_factors.append(RiskFactor(
                factor_name="New Beneficiary Account",
                impact_score=15.0,
                severity="MEDIUM",
                description=f"Account registered only {account_age} days ago"
            ))

        # -----------------------------------------------------------------
        # CATEGORY 6 & 7: Phishing Payment Links & Fake KYC Updates
        # -----------------------------------------------------------------
        is_payment_link = channel == "PAYMENT_LINK"
        has_kyc_trigger = any(kw in note for kw in KYC_PANIC_KEYWORDS)

        if has_kyc_trigger:
            penalty_score += 50.0
            if primary_category == "NORMAL":
                primary_category = "FAKE_KYC_ACCOUNT_BLOCK_THREAT"
            rule_hits.append(RuleHit(
                rule_code="KYC_PANIC_EXTORTION",
                category="FAKE_KYC_ACCOUNT_BLOCK_THREAT",
                title="Urgent KYC / Service Termination Threat",
                severity="CRITICAL",
                description="Payment or message contains coercive urgency regarding KYC expiry, account freeze, or electricity disconnection. Official banking guidelines state KYC is never updated via UPI payment."
            ))
            risk_factors.append(RiskFactor(
                factor_name="Coercive KYC Threat Indicator",
                impact_score=50.0,
                severity="CRITICAL",
                description="Urgent panic language threatening immediate account closure or power cutoff"
            ))
            prevention_steps.append("Banks never block accounts or ask for UPI transfers for KYC verification. Contact your local branch directly.")

        if is_payment_link and (has_kyc_trigger or penalty_score > 30):
            penalty_score += 25.0
            if primary_category == "NORMAL":
                primary_category = "PHISHING_PAYMENT_LINK"
            rule_hits.append(RuleHit(
                rule_code="SUSPICIOUS_PAYMENT_LINK_ROUTING",
                category="PHISHING_PAYMENT_LINK",
                title="Unverified Web Payment Link Routing",
                severity="HIGH",
                description="Payment link originating from third-party SMS or message with suspicious routing."
            ))
            risk_factors.append(RiskFactor(
                factor_name="Unverified External Payment Link",
                impact_score=25.0,
                severity="HIGH",
                description="Payment link redirects through non-standard banking gateway"
            ))

        # -----------------------------------------------------------------
        # Device Risk Hardware Signals
        # -----------------------------------------------------------------
        if dev:
            if dev.is_rooted_or_jailbroken:
                penalty_score += 25.0
                risk_factors.append(RiskFactor(
                    factor_name="Device Integrity Compromised (Rooted)",
                    impact_score=25.0,
                    severity="HIGH",
                    description="Operating system security sandbox disabled"
                ))
            if dev.ip_vpn_or_proxy:
                penalty_score += 15.0
                risk_factors.append(RiskFactor(
                    factor_name="Anonymizing Proxy/VPN Active",
                    impact_score=15.0,
                    severity="MEDIUM",
                    description="IP address geo-location masked"
                ))
            if dev.is_new_device and req.amount > 10000:
                penalty_score += 20.0
                risk_factors.append(RiskFactor(
                    factor_name="High-Value First Transaction on New Device",
                    impact_score=20.0,
                    severity="MEDIUM",
                    description="New device hardware fingerprint transferring > ₹10,000"
                ))

        # Safe defaults if no risk
        if not risk_factors:
            risk_factors.append(RiskFactor(
                factor_name="Standard Verification Checks Passed",
                impact_score=-20.0,
                severity="SAFE",
                description="No remote apps, established beneficiary age, valid channel parameters"
            ))
            prevention_steps.append("Transaction characteristics conform to standard safe UPI patterns.")

        return penalty_score, rule_hits, risk_factors, primary_category, prevention_steps

import uuid
import datetime
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.core.database import get_db
from app.models.db_models import MessageScanRecord
from app.models.schemas import MessageScanRequest, MessageScanResponse, ExtractedEntities
from app.services.nlp_engine import NLPEngine

router = APIRouter(prefix="/messages", tags=["Messages & Phishing Links"])

@router.post("/scan", response_model=MessageScanResponse)
def scan_message(req: MessageScanRequest, db: Session = Depends(get_db)):
    result = NLPEngine.analyze_message(req.raw_text, channel=req.channel_type or "SMS")
    
    scan_id = f"MSG-{uuid.uuid4().hex[:10].upper()}"
    now = datetime.datetime.utcnow()

    # Save to db
    record = MessageScanRecord(
        id=scan_id,
        raw_text=req.raw_text,
        channel_type=req.channel_type or "SMS",
        risk_score=result["risk_score"],
        risk_tier=result["risk_tier"],
        detected_category=result["detected_category"],
        is_malicious=result["is_malicious"],
        extracted_urls=result["extracted_entities"].urls,
        extracted_phones=result["extracted_entities"].phones,
        extracted_vpas=result["extracted_entities"].vpas,
        extracted_apk_names=result["extracted_entities"].apks,
        suspicious_tokens=result["extracted_entities"].suspicious_phrases,
        explanation=result["explanation"],
        recommended_action=result["recommended_action"],
        created_at=now
    )
    db.add(record)
    db.commit()

    return MessageScanResponse(
        scan_id=scan_id,
        raw_text=req.raw_text,
        channel_type=req.channel_type or "SMS",
        risk_score=result["risk_score"],
        risk_tier=result["risk_tier"],
        is_malicious=result["is_malicious"],
        detected_category=result["detected_category"],
        extracted_entities=result["extracted_entities"],
        explanation=result["explanation"],
        recommended_action=result["recommended_action"],
        cyber_cell_advisory=result["cyber_cell_advisory"],
        created_at=now.isoformat()
    )

@router.get("/recent")
def get_recent_message_scans(limit: int = Query(20, le=50), db: Session = Depends(get_db)):
    records = db.query(MessageScanRecord).order_by(desc(MessageScanRecord.created_at)).limit(limit).all()
    return [
        {
            "id": r.id,
            "raw_text": r.raw_text,
            "channel_type": r.channel_type,
            "risk_score": r.risk_score,
            "risk_tier": r.risk_tier,
            "detected_category": r.detected_category,
            "is_malicious": r.is_malicious,
            "urls_count": len(r.extracted_urls or []),
            "phones_count": len(r.extracted_phones or []),
            "created_at": r.created_at.isoformat() if r.created_at else None
        }
        for r in records
    ]

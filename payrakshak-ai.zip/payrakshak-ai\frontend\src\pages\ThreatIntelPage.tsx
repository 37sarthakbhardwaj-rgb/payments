import React, { useState, useEffect } from 'react';
import {
  Database,
  Search,
  Plus,
  ShieldAlert,
  Filter,
  ExternalLink,
  Phone,
  Link2,
  FileCode,
  CheckCircle2,
  X
} from 'lucide-react';
import { api } from '../services/api';
import { ThreatIntelItem } from '../types';

export const ThreatIntelPage: React.FC = () => {
  const [intelList, setIntelList] = useState<ThreatIntelItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  // New Indicator Form State
  const [newType, setNewType] = useState('VPA');
  const [newValue, setNewValue] = useState('');
  const [newCategory, setNewCategory] = useState('FAKE_COLLECT_REFUND_SCAM');
  const [newDesc, setNewDesc] = useState('');
  const [newSource, setNewSource] = useState('I4C / 1930 Cyber Cell');

  const fetchIntel = async () => {
    setLoading(true);
    try {
      const data = await api.getThreatIntel(selectedType || undefined, searchTerm || undefined);
      setIntelList(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIntel();
  }, [selectedType, searchTerm]);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.addThreatIntel({
        indicator_type: newType,
        indicator_value: newValue,
        threat_category: newCategory,
        risk_level: 'CRITICAL',
        description: newDesc,
        source: newSource,
      });
      setShowAddModal(false);
      setNewValue('');
      setNewDesc('');
      fetchIntel();
    } catch (err) {
      console.error(err);
    }
  };

  const getIndicatorIcon = (type: string) => {
    switch (type) {
      case 'VPA':
        return Database;
      case 'URL':
        return Link2;
      case 'PHONE':
        return Phone;
      case 'APK':
        return FileCode;
      default:
        return ShieldAlert;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 rounded-2xl bg-navy-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Database className="h-5 w-5 text-cyan-400" />
            <h1 className="text-xl font-bold text-white tracking-tight">
              National Threat Intelligence Feed
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-400 max-w-xl">
            Live repository of flagged scam UPI handles, phishing domains, fraudulent customer-care numbers, and trojan APK signatures synced with Indian cyber crime databases.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="py-2.5 px-4 rounded-xl font-bold font-mono text-xs text-navy-950 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 shadow-lg shadow-cyan-500/25 flex items-center space-x-2 self-start md:self-auto"
        >
          <Plus className="h-4 w-4" />
          <span>REPORT / ADD INDICATOR</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by VPA handle, domain URL, phone number, or description..."
            className="w-full bg-navy-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs font-mono text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
          />
        </div>

        <div className="flex items-center space-x-1.5 bg-navy-900 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
          {['', 'VPA', 'URL', 'PHONE', 'APK'].map((type) => (
            <button
              key={type}
              onClick={() => setSelectedType(type)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                selectedType === type
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {type === '' ? 'All Types' : type}
            </button>
          ))}
        </div>
      </div>

      {/* Threat Intel Table */}
      <div className="rounded-2xl bg-navy-900/90 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-navy-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">Type</th>
                <th className="p-3.5">Indicator of Compromise (IoC)</th>
                <th className="p-3.5">Threat Category</th>
                <th className="p-3.5">Risk Level</th>
                <th className="p-3.5">Source / Reported By</th>
                <th className="p-3.5">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-navy-900/60">
              {intelList.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500">
                    No threat indicators match the current query.
                  </td>
                </tr>
              ) : (
                intelList.map((item) => {
                  const Icon = getIndicatorIcon(item.indicator_type);
                  return (
                    <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-3.5">
                        <span className="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded bg-slate-800 text-[10px] text-cyan-300 font-semibold border border-slate-700">
                          <Icon className="h-3 w-3" />
                          <span>{item.indicator_type}</span>
                        </span>
                      </td>
                      <td className="p-3.5 font-bold text-white max-w-[220px] truncate">
                        {item.indicator_value}
                      </td>
                      <td className="p-3.5 text-cyan-400">{item.threat_category}</td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-400 font-bold text-[10px] border border-red-500/30">
                          {item.risk_level}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-400 text-[11px]">{item.source}</td>
                      <td className="p-3.5 text-slate-300 text-[11px] max-w-sm truncate">
                        {item.description}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Indicator Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-navy-900 border border-slate-700 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white font-mono">Report Threat Indicator</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleAdd} className="space-y-3 font-mono text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Indicator Type</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value)}
                  className="w-full bg-navy-950 border border-slate-700 rounded-lg p-2 text-white focus:outline-none"
                >
                  <option value="VPA">VPA (UPI ID)</option>
                  <option value="URL">URL / Phishing Domain</option>
                  <option value="PHONE">Phone Number</option>
                  <option value="APK">Malicious APK File</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Indicator Value</label>
                <input
                  type="text"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  placeholder="e.g. scammer.desk@ybl or http://fake-kyc.online"
                  className="w-full bg-navy-950 border border-slate-700 rounded-lg p-2 text-white focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Scam Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full bg-navy-950 border border-slate-700 rounded-lg p-2 text-white focus:outline-none"
                >
                  <option value="FAKE_COLLECT_REFUND_SCAM">Fake Collect / Refund Scam</option>
                  <option value="QR_CODE_PAYMENT_SCAM">QR Code Payment Scam</option>
                  <option value="REMOTE_ACCESS_APP_SCAM">Remote Access App Scam</option>
                  <option value="FAKE_INVESTMENT_JOB_SCAM">Fake Investment / Job Offer Scam</option>
                  <option value="MULE_ACCOUNT_PATTERNS">Mule Account / Velocity Pattern</option>
                  <option value="PHISHING_PAYMENT_LINK">Phishing Link / Malicious Site</option>
                  <option value="FAKE_KYC_ACCOUNT_BLOCK_THREAT">Fake KYC / Account Block Threat</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Reporting Source</label>
                <input
                  type="text"
                  value={newSource}
                  onChange={(e) => setNewSource(e.target.value)}
                  className="w-full bg-navy-950 border border-slate-700 rounded-lg p-2 text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Description / Modus Operandi</label>
                <textarea
                  rows={3}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Describe the scam or reported victim incident..."
                  className="w-full bg-navy-950 border border-slate-700 rounded-lg p-2 text-white focus:outline-none"
                  required
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-cyan-400 text-navy-950 font-bold"
                >
                  Add to Repository
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Cpu,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  Info,
  Layers,
  Activity
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell
} from 'recharts';
import { api } from '../services/api';
import { MetricCard } from '../components/MetricCard';
import { MLModelInsights } from '../types';

export const ModelAnalytics: React.FC = () => {
  const [insights, setInsights] = useState<MLModelInsights | null>(null);
  const [batchSize, setBatchSize] = useState<number>(500);
  const [batchRunning, setBatchRunning] = useState<boolean>(false);
  const [batchResult, setBatchResult] = useState<any | null>(null);

  useEffect(() => {
    api.getMLInsights().then(setInsights).catch(console.error);
  }, []);

  const handleRunBatch = async () => {
    setBatchRunning(true);
    try {
      const res = await api.runSyntheticBatch(batchSize);
      setBatchResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setBatchRunning(false);
    }
  };

  // Prepare feature importance data
  const featureData = insights?.feature_importances
    ? Object.entries(insights.feature_importances)
        .map(([name, weight]) => ({
          name: name.replace('ch_', 'channel_').replace('_', ' '),
          weight: Math.round(weight * 1000) / 10,
        }))
        .slice(0, 10)
    : [];

  const cm = insights?.confusion_matrix || [[0, 0], [0, 0]];
  const tn = cm[0]?.[0] ?? 0;
  const fp = cm[0]?.[1] ?? 0;
  const fn = cm[1]?.[0] ?? 0;
  const tp = cm[1]?.[1] ?? 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 rounded-2xl bg-navy-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Cpu className="h-5 w-5 text-cyan-400" />
            <h1 className="text-xl font-bold text-white tracking-tight">
              Machine Learning Model Architecture & Offline Benchmark
            </h1>
          </div>
          <p className="mt-1 text-xs text-slate-400 max-w-xl">
            Offline evaluation metrics measured against an independent held-out test split of 1,200 labeled synthetic transactions (Random Forest + Gradient Boosting calibrated ensemble).
          </p>
        </div>

        <div className="bg-navy-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono text-cyan-300">
          Model: <span className="text-white font-bold">{insights?.model_name || 'PayRakshak-v1.0'}</span>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard
          title="Fraud Detection Rate"
          value={insights ? `${(insights.fraud_detection_rate * 100).toFixed(1)}%` : '---'}
          subtitle="Test Recall / Sensitivity"
          icon={CheckCircle2}
          variant="green"
        />
        <MetricCard
          title="False Positive Rate"
          value={insights ? `${(insights.false_positive_rate * 100).toFixed(1)}%` : '---'}
          subtitle="FP / (FP + TN)"
          icon={CheckCircle2}
          variant="cyan"
        />
        <MetricCard
          title="Accuracy"
          value={insights ? `${(insights.accuracy * 100).toFixed(1)}%` : '---'}
          subtitle="Overall test accuracy"
          icon={Cpu}
          variant="default"
        />
        <MetricCard
          title="Precision"
          value={insights ? `${(insights.precision * 100).toFixed(1)}%` : '---'}
          subtitle="TP / (TP + FP)"
          icon={Cpu}
          variant="default"
        />
        <MetricCard
          title="F1-Score"
          value={insights ? `${(insights.f1_score * 100).toFixed(1)}%` : '---'}
          subtitle="Harmonic mean"
          icon={Cpu}
          variant="default"
        />
        <MetricCard
          title="ROC-AUC"
          value={insights ? `${insights.roc_auc.toFixed(3)}` : '---'}
          subtitle="Discriminative power"
          icon={Cpu}
          variant="default"
        />
      </div>

      {/* Confusion Matrix and Feature Importances */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Confusion Matrix */}
        <div className="lg:col-span-5 rounded-2xl bg-navy-900 border border-slate-800 p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-white font-mono uppercase">
                Held-Out Test Set Confusion Matrix
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                N = {insights?.test_samples || 1200}
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              True Labels vs Model Predicted Classifications
            </p>

            {/* Matrix 2x2 Grid */}
            <div className="grid grid-cols-2 gap-3 font-mono text-center">
              {/* True Negative */}
              <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex flex-col justify-center">
                <span className="text-[10px] text-emerald-400 uppercase tracking-wider block">
                  True Negative (TN)
                </span>
                <span className="text-2xl font-bold text-white mt-1">{tn}</span>
                <span className="text-[10px] text-slate-400 mt-1">Legitimate allowed</span>
              </div>

              {/* False Positive */}
              <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/30 flex flex-col justify-center">
                <span className="text-[10px] text-amber-400 uppercase tracking-wider block">
                  False Positive (FP)
                </span>
                <span className="text-2xl font-bold text-amber-400 mt-1">{fp}</span>
                <span className="text-[10px] text-slate-400 mt-1">False alarm (friction)</span>
              </div>

              {/* False Negative */}
              <div className="p-4 rounded-xl bg-red-950/30 border border-red-500/30 flex flex-col justify-center">
                <span className="text-[10px] text-red-400 uppercase tracking-wider block">
                  False Negative (FN)
                </span>
                <span className="text-2xl font-bold text-red-400 mt-1">{fn}</span>
                <span className="text-[10px] text-slate-400 mt-1">Missed fraud</span>
              </div>

              {/* True Positive */}
              <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/30 flex flex-col justify-center">
                <span className="text-[10px] text-cyan-400 uppercase tracking-wider block">
                  True Positive (TP)
                </span>
                <span className="text-2xl font-bold text-cyan-300 mt-1">{tp}</span>
                <span className="text-[10px] text-slate-400 mt-1">Scams intercepted</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>Train split: {insights?.train_samples || 4800} txns</span>
            <span className="text-cyan-400">Test split: {insights?.test_samples || 1200} txns</span>
          </div>
        </div>

        {/* Feature Importances Bar Chart */}
        <div className="lg:col-span-7 rounded-2xl bg-navy-900 border border-slate-800 p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-white font-mono uppercase">
                Top 10 Feature Importances (Gini Weight)
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                Random Forest
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Relative contribution of behavioral, device, and channel indicators to scam detection
            </p>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={featureData} layout="vertical" margin={{ top: 5, right: 30, left: 70, bottom: 5 }}>
                  <XAxis type="number" stroke="#64748B" fontSize={11} unit="%" />
                  <YAxis type="category" dataKey="name" stroke="#94A3B8" fontSize={10} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0F172A',
                      borderColor: '#334155',
                      borderRadius: '8px',
                      fontSize: '11px',
                      fontFamily: 'monospace',
                    }}
                  />
                  <Bar dataKey="weight" fill="#06B6D4" radius={[0, 4, 4, 0]}>
                    {featureData.map((_, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={index < 3 ? '#00F2FE' : index < 6 ? '#38BDF8' : '#3B82F6'}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Live Synthetic Batch Evaluator */}
      <div className="rounded-2xl bg-navy-900 border border-slate-800 p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Activity className="h-4 w-4 text-cyan-400" />
              <span>Run Live Synthetic Evaluation Batch</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Generate a brand-new live synthetic test stream and immediately calculate empirical accuracy and confusion matrix.
            </p>
          </div>

          <div className="flex items-center space-x-3 self-start sm:self-auto font-mono text-xs">
            <select
              value={batchSize}
              onChange={(e) => setBatchSize(Number(e.target.value))}
              className="bg-navy-950 border border-slate-700 text-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none"
            >
              <option value={250}>250 Samples</option>
              <option value={500}>500 Samples</option>
              <option value={1000}>1,000 Samples</option>
            </select>

            <button
              onClick={handleRunBatch}
              disabled={batchRunning}
              className="py-2 px-4 rounded-xl font-bold font-mono text-xs text-navy-950 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 shadow-md flex items-center space-x-2 disabled:opacity-50"
            >
              <Play className="h-3 w-3 fill-navy-950" />
              <span>{batchRunning ? 'Evaluating...' : 'RUN LIVE BATCH'}</span>
            </button>
          </div>
        </div>

        {/* Live Batch Result */}
        {batchResult && (
          <div className="mt-4 p-4 rounded-xl bg-navy-950 border border-cyan-500/30 font-mono text-xs animate-in fade-in">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-2.5 rounded-lg bg-navy-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Sample Batch</span>
                <span className="text-base font-bold text-white">{batchResult.sample_size} txns</span>
              </div>
              <div className="p-2.5 rounded-lg bg-navy-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Empirical Detection Rate</span>
                <span className="text-base font-bold text-emerald-400">{batchResult.fraud_detection_rate}%</span>
              </div>
              <div className="p-2.5 rounded-lg bg-navy-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Empirical False Positive</span>
                <span className="text-base font-bold text-cyan-400">{batchResult.false_positive_rate}%</span>
              </div>
              <div className="p-2.5 rounded-lg bg-navy-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">F1-Score</span>
                <span className="text-base font-bold text-amber-400">{batchResult.f1_score}%</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

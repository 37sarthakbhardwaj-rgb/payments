import pytest
from app.models.schemas import TransactionScanRequest, DeviceRiskSignals
from app.services.ml_engine import MLEngine

def test_ml_model_training_and_metrics():
    clf, metrics = MLEngine.get_or_load_model()
    assert clf is not None
    assert "accuracy" in metrics
    assert "fraud_detection_rate" in metrics
    assert "false_positive_rate" in metrics
    assert metrics["accuracy"] > 0.85
    assert metrics["fraud_detection_rate"] > 0.85

def test_ml_prediction_pipeline():
    req = TransactionScanRequest(
        sender_vpa="victim@oksbi",
        payee_vpa="lottery.claim@ybl",
        payee_name="Mega Prize Winner Claim",
        amount=5000.0,
        channel="STATIC_QR",
        note="Scan QR to claim lottery prize",
        payee_account_age_days=2,
        payee_velocity_1h=25,
        device_signals=DeviceRiskSignals()
    )
    result = MLEngine.predict_request(req)
    assert result["risk_score"] > 60.0
    assert result["is_flagged"] is True
    assert result["risk_tier"] in ["HIGH", "CRITICAL"]
    assert len(result["risk_factors"]) > 0

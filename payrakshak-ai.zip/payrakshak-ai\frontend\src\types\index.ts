export interface DeviceRiskSignals {
  remote_access_app_detected: boolean;
  screen_sharing_active: boolean;
  call_in_progress: boolean;
  is_new_device: boolean;
  is_rooted_or_jailbroken: boolean;
  ip_vpn_or_proxy: boolean;
  location_mismatch?: boolean;
}

export interface RiskFactor {
  factor_name: string;
  impact_score: number;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'SAFE';
  description: string;
}

export interface RuleHit {
  rule_code: string;
  category: string;
  title: string;
  severity: string;
  description: string;
}

export interface TransactionScanRequest {
  sender_vpa: string;
  payee_vpa: string;
  payee_name: string;
  amount: number;
  channel: string;
  note?: string;
  payee_account_age_days?: number;
  payee_velocity_1h?: number;
  device_signals?: DeviceRiskSignals;
}

export interface TransactionScanResponse {
  transaction_id: string;
  sender_vpa: string;
  payee_vpa: string;
  payee_name: string;
  amount: number;
  channel: string;
  risk_score: number;
  risk_tier: 'SAFE' | 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  scam_category: string;
  is_flagged: boolean;
  recommended_action: string;
  explanation_summary: string;
  risk_factors: RiskFactor[];
  rules_triggered: RuleHit[];
  prevention_steps: string[];
  device_signals: Record<string, any>;
  timestamp: string;
}

export interface TransactionSummaryItem {
  id: string;
  sender_vpa: string;
  payee_vpa: string;
  payee_name: string;
  amount: number;
  channel: string;
  note?: string;
  timestamp: string;
  risk_score: number;
  risk_tier: string;
  scam_category: string;
  is_flagged: boolean;
  recommended_action: string;
  explanation_summary: string;
  rules_count: number;
  device_signals?: Record<string, any>;
}

export interface ExtractedEntities {
  urls: string[];
  phones: string[];
  vpas: string[];
  apks: string[];
  suspicious_phrases: string[];
}

export interface MessageScanResponse {
  scan_id: string;
  raw_text: string;
  channel_type: string;
  risk_score: number;
  risk_tier: string;
  is_malicious: boolean;
  detected_category: string;
  extracted_entities: ExtractedEntities;
  explanation: string;
  recommended_action: string;
  cyber_cell_advisory: string;
  created_at: string;
}

export interface OverviewStats {
  total_transactions_analyzed: number;
  flagged_suspicious_count: number;
  high_critical_risk_count: number;
  safe_transactions_count: number;
  fraud_share_percentage: number;
  offline_fraud_detection_rate: number;
  offline_false_positive_rate: number;
  offline_accuracy: number;
  offline_precision: number;
  offline_f1_score: number;
  offline_roc_auc: number;
  offline_test_samples: number;
  live_vs_offline_explanation: string;
}

export interface FraudCategoryStat {
  category: string;
  count: number;
  percentage: number;
  avg_risk_score: number;
  sample_scam_name: string;
}

export interface RiskLevelStat {
  tier: string;
  count: number;
  percentage: number;
  color: string;
}

export interface ActivityTimePoint {
  time_label: string;
  total_volume: number;
  legitimate_volume: number;
  flagged_volume: number;
}

export interface ThreatIntelItem {
  id: number;
  indicator_type: string;
  indicator_value: string;
  threat_category: string;
  risk_level: string;
  description: string;
  source: string;
  is_active: boolean;
  reported_date: string;
}

export interface ScenarioItem {
  id: string;
  title: string;
  subtitle: string;
  scam_category: string;
  icon_name: string;
  sample_request: TransactionScanRequest;
  context_story: string;
  modus_operandi: string;
  what_would_happen_without_ai: string;
}

export interface MLModelInsights {
  model_name: string;
  train_samples: number;
  test_samples: number;
  accuracy: number;
  precision: number;
  recall: number;
  f1_score: number;
  roc_auc: number;
  fraud_detection_rate: number;
  false_positive_rate: number;
  confusion_matrix: number[][];
  feature_importances: Record<string, number>;
}

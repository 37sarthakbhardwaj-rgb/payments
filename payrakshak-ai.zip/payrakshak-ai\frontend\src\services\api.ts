import {
  TransactionScanRequest,
  TransactionScanResponse,
  TransactionSummaryItem,
  MessageScanResponse,
  OverviewStats,
  FraudCategoryStat,
  RiskLevelStat,
  ActivityTimePoint,
  ThreatIntelItem,
  ScenarioItem,
  MLModelInsights
} from '../types';

const API_BASE = 'http://localhost:8000/api/v1';

export const api = {
  // Transactions
  scanTransaction: async (data: TransactionScanRequest): Promise<TransactionScanResponse> => {
    const res = await fetch(`${API_BASE}/transactions/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error(`Scan failed: ${res.statusText}`);
    return res.json();
  },

  getRecentTransactions: async (filterBy?: string, limit = 50): Promise<TransactionSummaryItem[]> => {
    const url = new URL(`${API_BASE}/transactions/recent`);
    if (filterBy) url.searchParams.append('filter_by', filterBy);
    url.searchParams.append('limit', limit.toString());
    const res = await fetch(url.toString());
    if (!res.ok) throw new Error('Failed to fetch recent transactions');
    return res.json();
  },

  getTransactionDetail: async (id: string): Promise<any> => {
    const res = await fetch(`${API_BASE}/transactions/${id}`);
    if (!res.ok) throw new Error('Failed to fetch transaction details');
    return res.json();
  },

  // Messages / Phishing
  scanMessage: async (text: string, channelType = 'SMS'): Promise<MessageScanResponse> => {
    const res = await fetch(`${API_BASE}/messages/scan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ raw_text: text, channel_type: channelType }),
    });
    if (!res.ok) throw new Error('Message scan failed');
    return res.json();
  },

  getRecentMessageScans: async (): Promise<any[]> => {
    const res = await fetch(`${API_BASE}/messages/recent`);
    if (!res.ok) throw new Error('Failed to fetch message scans');
    return res.json();
  },

  // Analytics
  getOverviewStats: async (): Promise<OverviewStats> => {
    const res = await fetch(`${API_BASE}/analytics/overview`);
    if (!res.ok) throw new Error('Failed to fetch overview stats');
    return res.json();
  },

  getCategories: async (): Promise<FraudCategoryStat[]> => {
    const res = await fetch(`${API_BASE}/analytics/categories`);
    if (!res.ok) throw new Error('Failed to fetch categories');
    return res.json();
  },

  getActivity: async (): Promise<ActivityTimePoint[]> => {
    const res = await fetch(`${API_BASE}/analytics/activity`);
    if (!res.ok) throw new Error('Failed to fetch activity');
    return res.json();
  },

  getRiskDistribution: async (): Promise<RiskLevelStat[]> => {
    const res = await fetch(`${API_BASE}/analytics/risk-distribution`);
    if (!res.ok) throw new Error('Failed to fetch risk distribution');
    return res.json();
  },

  getMLInsights: async (): Promise<MLModelInsights> => {
    const res = await fetch(`${API_BASE}/analytics/ml-insights`);
    if (!res.ok) throw new Error('Failed to fetch ML insights');
    return res.json();
  },

  // Scenarios
  getScenarios: async (): Promise<ScenarioItem[]> => {
    const res = await fetch(`${API_BASE}/scenarios/list`);
    if (!res.ok) throw new Error('Failed to fetch scenarios');
    return res.json();
  },

  // Threat Intel
  getThreatIntel: async (indicatorType?: string, search?: string): Promise<ThreatIntelItem[]> => {
    const url = new URL(`${API_BASE}/threat-intel/list`);
    if (indicatorType) url.searchParams.append('indicator_type', indicatorType);
    if (search) url.searchParams.append('search', search);
    const res = await fetch(url.toString());
    if (!res.ok) throw new Error('Failed to fetch threat intel');
    return res.json();
  },

  addThreatIntel: async (data: Partial<ThreatIntelItem>): Promise<ThreatIntelItem> => {
    const res = await fetch(`${API_BASE}/threat-intel/add`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to add threat indicator');
    return res.json();
  },

  // Batch Evaluation
  runSyntheticBatch: async (sampleSize = 500): Promise<any> => {
    const res = await fetch(`${API_BASE}/batch/evaluate-synthetic-batch?sample_size=${sampleSize}`, {
      method: 'POST',
    });
    if (!res.ok) throw new Error('Batch evaluation failed');
    return res.json();
  }
};

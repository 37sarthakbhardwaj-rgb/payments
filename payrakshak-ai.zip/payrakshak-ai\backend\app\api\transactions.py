import uuid
import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.core.database import get_db
from app.models.db_models import TransactionRecord, ThreatIntelligence
from app.models.schemas import TransactionScanRequest, TransactionScanResponse, RiskFactor, RuleHit
from app.services.ml_engine import MLEngine

router = APIRouter(prefix="/transactions", tags=["Transactions"])

@router.post("/scan", response_model=TransactionScanResponse)
def scan_transaction(req: TransactionScanRequest, db: Session = Depends(get_db)):
    # Fetch active threat VPAs
    threat_vpas = {
        row.indicator_value.lower()
        for row in db.query(ThreatIntelligence.indicator_value).filter(
            ThreatIntelligence.indicator_type == "VPA",
            ThreatIntelligence.is_active == True
        ).all()
    }

    # Run AI Detection Engine
    res = MLEngine.predict_request(req, threat_vpas=threat_vpas)

    txn_id = f"TXN-{uuid.uuid4().hex[:10].upper()}"
    now = datetime.datetime.utcnow()

    # Save to database
    record = TransactionRecord(
        id=txn_id,
        sender_vpa=req.sender_vpa,
        payee_vpa=req.payee_vpa,
        payee_name=req.payee_name,
        amount=req.amount,
        channel=req.channel,
        note=req.note,
        timestamp=now,
        risk_score=res["risk_score"],
        risk_tier=res["risk_tier"],
        scam_category=res["scam_category"],
        is_flagged=res["is_flagged"],
        recommended_action=res["recommended_action"],
        explanation_summary=res["explanation_summary"],
        feature_breakdown=res["risk_factors"],
        rules_triggered=res["rules_triggered"],
        device_signals=res["device_signals"],
        prevention_steps=res["prevention_steps"],
        ground_truth_fraud=None
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    return TransactionScanResponse(
        transaction_id=txn_id,
        sender_vpa=req.sender_vpa,
        payee_vpa=req.payee_vpa,
        payee_name=req.payee_name,
        amount=req.amount,
        channel=req.channel,
        risk_score=res["risk_score"],
        risk_tier=res["risk_tier"],
        scam_category=res["scam_category"],
        is_flagged=res["is_flagged"],
        recommended_action=res["recommended_action"],
        explanation_summary=res["explanation_summary"],
        risk_factors=[RiskFactor(**rf) for rf in res["risk_factors"]],
        rules_triggered=[RuleHit(**rh) for rh in res["rules_triggered"]],
        prevention_steps=res["prevention_steps"],
        device_signals=res["device_signals"],
        timestamp=now.isoformat()
    )

@router.get("/recent")
def get_recent_transactions(
    filter_by: Optional[str] = Query(None, description="all, flagged, high_risk"),
    limit: int = Query(50, le=100),
    db: Session = Depends(get_db)
):
    query = db.query(TransactionRecord)
    if filter_by == "flagged":
        query = query.filter(TransactionRecord.is_flagged == True)
    elif filter_by == "high_risk":
        query = query.filter(TransactionRecord.risk_tier.in_(["HIGH", "CRITICAL"]))

    records = query.order_by(desc(TransactionRecord.timestamp)).limit(limit).all()

    return [
        {
            "id": r.id,
            "sender_vpa": r.sender_vpa,
            "payee_vpa": r.payee_vpa,
            "payee_name": r.payee_name,
            "amount": r.amount,
            "channel": r.channel,
            "note": r.note,
            "timestamp": r.timestamp.isoformat() if r.timestamp else None,
            "risk_score": r.risk_score,
            "risk_tier": r.risk_tier,
            "scam_category": r.scam_category,
            "is_flagged": r.is_flagged,
            "recommended_action": r.recommended_action,
            "explanation_summary": r.explanation_summary,
            "rules_count": len(r.rules_triggered or []),
            "device_signals": r.device_signals
        }
        for r in records
    ]

@router.get("/{txn_id}")
def get_transaction_detail(txn_id: str, db: Session = Depends(get_db)):
    record = db.query(TransactionRecord).filter(TransactionRecord.id == txn_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Transaction not found")

    return {
        "id": record.id,
        "sender_vpa": record.sender_vpa,
        "payee_vpa": record.payee_vpa,
        "payee_name": record.payee_name,
        "amount": record.amount,
        "channel": record.channel,
        "note": record.note,
        "timestamp": record.timestamp.isoformat() if record.timestamp else None,
        "risk_score": record.risk_score,
        "risk_tier": record.risk_tier,
        "scam_category": record.scam_category,
        "is_flagged": record.is_flagged,
        "recommended_action": record.recommended_action,
        "explanation_summary": record.explanation_summary,
        "risk_factors": record.feature_breakdown or [],
        "rules_triggered": record.rules_triggered or [],
        "device_signals": record.device_signals or {},
        "prevention_steps": record.prevention_steps or []
    }

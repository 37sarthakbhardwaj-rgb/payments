import re
import os
import joblib
from typing import Dict, Any, List, Tuple
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from app.models.schemas import ExtractedEntities, MessageScanResponse
from app.core.config import settings

# Regex patterns for Indian context
URL_PATTERN = re.compile(r'(https?://[^\s]+|www\.[^\s]+|[a-zA-Z0-9_\-]+\.(?:com|in|org|net|xyz|top|online|site|cc|info|app|live)/[^\s]*)', re.IGNORECASE)
PHONE_PATTERN = re.compile(r'(?:\+91[\-\s]?)?[6789]\d{9}|1800[\-\s]?\d{3}[\-\s]?\d{3,4}')
UPI_PATTERN = re.compile(r'[\w\.\-]+@(?:okhdfcbank|okaxis|oksbi|okicici|paytm|ybl|ibl|axl|upi|sbi|barodampay|pnb)')
APK_PATTERN = re.compile(r'[\w\-]+\.apk', re.IGNORECASE)

# Shortener domains frequently abused in Indian SMS scams
SHORTENERS = ["bit.ly", "tinyurl.com", "is.gd", "t.co", "cutt.ly", "rb.gy", "ngrok.io", "page.link"]

# Synthetic training dataset for SMS / Message Phishing
CORPUS_DATA = [
    # 1. Fake KYC / Account Blocking Threats
    ("Dear SBI user, your YONO account will be blocked today due to expired KYC. Update PAN immediately at http://bit.ly/sbi-pan-upd", "FAKE_KYC_ACCOUNT_BLOCK_THREAT"),
    ("HDFC Bank Alert: Your netbanking is suspended. Verify Aadhaar number now to avoid fine at http://hdfc-verify-sec.online", "FAKE_KYC_ACCOUNT_BLOCK_THREAT"),
    ("Electricity Power Alert: Your power supply will be disconnected tonight at 9:30 PM due to unpaid bill. Call officer at 9876543210 immediately.", "FAKE_KYC_ACCOUNT_BLOCK_THREAT"),
    ("Dear Customer, SIM card deactivation notice: Update KYC within 24 hours by dialling customer care 1800-999-888 to avoid SIM block.", "FAKE_KYC_ACCOUNT_BLOCK_THREAT"),
    ("PNB Alert: Your debit card is blocked. Please login to https://pnb-card-reactivate.xyz to restore card privileges.", "FAKE_KYC_ACCOUNT_BLOCK_THREAT"),

    # 2. Fake Customer Care & Remote Access
    ("Airtel Support: We noticed network latency. Please install QuickSupport app and share code with agent at 9123456789 to fix.", "REMOTE_ACCESS_APP_SCAM"),
    ("Dear user, your Google Pay refund failed. Call Google Pay senior support helpline 9811223344 and install AnyDesk to get refund.", "REMOTE_ACCESS_APP_SCAM"),
    ("PhonePe Care: For uncredited cashback of Rs 2000, download TeamViewer QuickSupport and accept agent connection to receive money.", "REMOTE_ACCESS_APP_SCAM"),
    ("SBI Customer Care: Call 8765432109 to reverse unauthorized transaction. Download SBI_Support.apk to process instant reversal.", "REMOTE_ACCESS_APP_SCAM"),

    # 3. Fake Collect / Refund / Reversal
    ("You have won Rs 5,000 scratch card reward on PhonePe! Click approve on collect request and enter UPI PIN to receive money in bank.", "FAKE_COLLECT_REFUND_SCAM"),
    ("OLX Buyer: I have sent collect request of Rs 15,000 for your sofa. Enter your UPI PIN to accept payment directly into your account.", "FAKE_COLLECT_REFUND_SCAM"),
    ("Swiggy Refund: Your refund of Rs 850 is ready. Please approve the collect request sent to your UPI ID rahul@okaxis.", "FAKE_COLLECT_REFUND_SCAM"),

    # 4. QR Code Scam
    ("Dear Winner, Scan this QR code with Google Pay / Paytm to claim your Diwali gift bonus of Rs 10,000 directly.", "QR_CODE_PAYMENT_SCAM"),
    ("Cashback alert: Scan the received QR image on WhatsApp to receive payment of Rs 2,500 credited to your account.", "QR_CODE_PAYMENT_SCAM"),

    # 5. Fake Investment & Job Offers
    ("Work from home part-time: Earn Rs 3,000 to Rs 8,000 daily by rating hotels and subscribing YouTube videos. Join Telegram @VIP_Wealth_Tasks", "FAKE_INVESTMENT_JOB_SCAM"),
    ("Part-time job offer: Amazon merchant rating tasks. Earn 30% daily ROI. Initial deposit only Rs 1,000. Contact HR on WhatsApp 9988776655.", "FAKE_INVESTMENT_JOB_SCAM"),
    ("Crypto trading bot guaranteed 200% return in 48 hours. Transfer USDT or deposit UPI to trader.growth@ybl to start.", "FAKE_INVESTMENT_JOB_SCAM"),

    # 6. Malicious Payment Links & Phishing
    ("Congratulations! You have received a lottery prize of Rs 25 Lakh in KBC Jio Lucky Draw. Click http://kbc-jio-lottery2026.top to claim.", "PHISHING_PAYMENT_LINK"),
    ("Income tax refund of Rs 18,500 has been approved. Confirm your account details and card CVV at http://incometax-refund-gov.site", "PHISHING_PAYMENT_LINK"),
    ("Download our new Rummy Gold game and get Rs 500 free cash. Download APK from http://download-rummy-pro.xyz/app.apk", "PHISHING_PAYMENT_LINK"),

    # 7. Legitimate Communications (Normal)
    ("Dear Customer, Rs 1,250.00 debited from a/c **4321 on 14-Oct-26 via UPI ref 428712398129 to DMart Groceries. Avl Bal: Rs 45,820.", "LEGITIMATE"),
    ("Your OTP for HDFC Bank NetBanking transaction of Rs 450.00 is 849201. Do not share OTP with anyone, bank never asks for OTP.", "LEGITIMATE"),
    ("Hi Rahul, let's split the dinner bill from yesterday. I've sent you Rs 600 via Google Pay.", "LEGITIMATE"),
    ("Your Amazon delivery agent is out for delivery. Share delivery code 4291 with agent upon package arrival.", "LEGITIMATE"),
    ("Electricity bill of Rs 1,420 for Consumer No 9812039 is generated. Due date is 25-Oct-26. Pay securely via BESCOM app.", "LEGITIMATE"),
    ("Dear Customer, your salary of Rs 75,000 has been credited to your ICICI Bank account on 30-Sep-26. Reference CMS491029.", "LEGITIMATE")
]

class NLPEngine:
    _model = None

    @classmethod
    def get_or_train_model(cls):
        if cls._model is not None:
            return cls._model

        model_path = os.path.join(settings.ML_MODEL_DIR, "nlp_phishing_model.joblib")
        if os.path.exists(model_path):
            try:
                cls._model = joblib.load(model_path)
                return cls._model
            except Exception:
                pass

        # Train a robust TF-IDF + Multinomial Naive Bayes pipeline
        texts = [item[0] for item in CORPUS_DATA]
        labels = [item[1] for item in CORPUS_DATA]

        pipeline = Pipeline([
            ('tfidf', TfidfVectorizer(ngram_range=(1, 2), lowercase=True, max_features=1000)),
            ('clf', MultinomialNB(alpha=0.1))
        ])
        pipeline.fit(texts, labels)

        os.makedirs(settings.ML_MODEL_DIR, exist_ok=True)
        try:
            joblib.dump(pipeline, model_path)
        except Exception:
            pass

        cls._model = pipeline
        return cls._model

    @classmethod
    def extract_entities(cls, text: str) -> ExtractedEntities:
        urls = URL_PATTERN.findall(text)
        phones = PHONE_PATTERN.findall(text)
        vpas = UPI_PATTERN.findall(text)
        apks = APK_PATTERN.findall(text)

        suspicious_phrases = []
        lower_text = text.lower()

        keywords = [
            "blocked", "suspended", "disconnected", "update pan", "update kyc",
            "enter upi pin to receive", "approve to receive", "scan qr to receive",
            "anydesk", "teamviewer", "quicksupport", "daily income", "part time",
            "telegram", "lottery", "electricity bill", "won rs", "scratch card"
        ]
        for kw in keywords:
            if kw in lower_text:
                suspicious_phrases.append(kw)

        return ExtractedEntities(
            urls=list(set(urls)),
            phones=list(set(phones)),
            vpas=list(set(vpas)),
            apks=list(set(apks)),
            suspicious_phrases=suspicious_phrases
        )

    @classmethod
    def analyze_message(cls, text: str, channel: str = "SMS") -> Dict[str, Any]:
        entities = cls.extract_entities(text)
        model = cls.get_or_train_model()

        # ML prediction
        predicted_category = model.predict([text])[0]
        proba = model.predict_proba([text])[0]
        classes = list(model.classes_)
        cat_idx = classes.index(predicted_category)
        confidence = float(proba[cat_idx])

        # Heuristic scoring boost
        risk_score = 0.0
        reasons = []

        if predicted_category != "LEGITIMATE":
            risk_score += (confidence * 60.0)

        # Check for shortened URLs
        has_shortener = any(any(s in u.lower() for s in SHORTENERS) for u in entities.urls)
        if has_shortener:
            risk_score += 25.0
            reasons.append("Contains masked URL shortener link commonly used to hide phishing destinations.")

        # Check for APK downloads
        if entities.apks or ".apk" in text.lower():
            risk_score += 35.0
            reasons.append("Prompts downloading an untrusted Android application package (.apk file).")

        # Check for remote desktop keywords
        if any(app in text.lower() for app in ["anydesk", "teamviewer", "quicksupport", "rustdesk"]):
            risk_score += 40.0
            reasons.append("Instructs user to install a remote access / screen-sharing application.")

        # Check for UPI PIN inversion trick
        if "enter" in text.lower() and "pin" in text.lower() and ("receive" in text.lower() or "credit" in text.lower()):
            risk_score += 50.0
            reasons.append("Classic UPI PIN Inversion: Claims entering UPI PIN will receive money (which actually debits).")

        # Check for coercive urgency
        if any(w in text.lower() for w in ["disconnected tonight", "blocked today", "within 24 hours", "electricity"]):
            risk_score += 20.0
            reasons.append("Employs artificial panic/urgency regarding immediate service suspension.")

        # Cap score at 99.0
        risk_score = min(99.0, max(5.0 if predicted_category == "LEGITIMATE" else 30.0, risk_score))

        # Determine Tier
        if risk_score >= 80:
            risk_tier = "CRITICAL"
            recommended_action = "BLOCK_AND_REPORT"
        elif risk_score >= 50:
            risk_tier = "HIGH"
            recommended_action = "WARN_DO_NOT_CLICK"
        elif risk_score >= 25:
            risk_tier = "MODERATE"
            recommended_action = "VERIFY_SOURCE"
        else:
            risk_tier = "SAFE"
            recommended_action = "SAFE_TO_VIEW"

        is_malicious = risk_score >= 45.0

        explanation = f"Classification: {predicted_category}. "
        if reasons:
            explanation += " ".join(reasons)
        else:
            explanation += "Message does not exhibit recognized social engineering or phishing patterns."

        advisory = (
            "National Cyber Helpline: Call 1930 immediately or lodge complaint at cybercrime.gov.in. "
            "Remember: Banks NEVER request remote access apps, passwords, or UPI PINs for KYC/refunds."
        )

        return {
            "risk_score": round(risk_score, 1),
            "risk_tier": risk_tier,
            "is_malicious": is_malicious,
            "detected_category": predicted_category if is_malicious else "NORMAL_COMMUNICATION",
            "extracted_entities": entities,
            "explanation": explanation,
            "recommended_action": recommended_action,
            "cyber_cell_advisory": advisory
        }

import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { OverviewDashboard } from './pages/OverviewDashboard';
import { TransactionScanner } from './pages/TransactionScanner';
import { MessageScanner } from './pages/MessageScanner';
import { FraudSimulations } from './pages/FraudSimulations';
import { ThreatIntelPage } from './pages/ThreatIntelPage';
import { ModelAnalytics } from './pages/ModelAnalytics';
import { ScenarioItem } from './types';

export function App() {
  const [currentTab, setCurrentTab] = useState<string>('overview');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      window.location.reload();
    }, 600);
  };

  const handleSelectScenarioForScanner = (_scen: ScenarioItem) => {
    setCurrentTab('scanner');
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-navy-950 text-slate-100 font-sans">
      {/* Sidebar Navigation */}
      <Sidebar currentTab={currentTab} setCurrentTab={setCurrentTab} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Top Navbar */}
        <Navbar
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          onRefresh={handleRefresh}
          isRefreshing={isRefreshing}
        />

        {/* Scrollable Page Body */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-grid-pattern">
          <div className="max-w-7xl mx-auto pb-12">
            {currentTab === 'overview' && <OverviewDashboard />}
            {currentTab === 'scanner' && <TransactionScanner />}
            {currentTab === 'messages' && <MessageScanner />}
            {currentTab === 'simulations' && (
              <FraudSimulations onSelectScenarioForScanner={handleSelectScenarioForScanner} />
            )}
            {currentTab === 'threat-intel' && <ThreatIntelPage />}
            {currentTab === 'analytics' && <ModelAnalytics />}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;

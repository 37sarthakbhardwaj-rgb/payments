import os
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple, List, Optional
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix
)
from app.core.config import settings
from app.models.schemas import TransactionScanRequest, TransactionScanResponse, RiskFactor, RuleHit
from app.services.rule_engine import RuleEngine
from app.services.synthetic_data import generate_synthetic_transactions

FEATURE_COLUMNS = [
    "amount", "log_amount", "hour", "payee_account_age_days", "payee_velocity_1h",
    "remote_access_detected", "screen_sharing_active", "call_in_progress",
    "is_new_device", "is_rooted", "is_vpn",
    "ch_collect", "ch_static_qr", "ch_dynamic_qr", "ch_intent", "ch_paylink", "ch_netbanking"
]

class MLEngine:
    _model: Optional[RandomForestClassifier] = None
    _metrics: Optional[Dict[str, Any]] = None

    @classmethod
    def get_model_path(cls) -> str:
        return os.path.join(settings.ML_MODEL_DIR, "fraud_model.joblib")

    @classmethod
    def get_metrics_path(cls) -> str:
        return os.path.join(settings.ML_MODEL_DIR, "model_metrics.joblib")

    @classmethod
    def extract_features_from_df(cls, df: pd.DataFrame) -> pd.DataFrame:
        features = pd.DataFrame()
        features["amount"] = df["amount"].astype(float)
        features["log_amount"] = np.log1p(df["amount"].astype(float))
        features["hour"] = df["hour"].astype(int)
        features["payee_account_age_days"] = df["payee_account_age_days"].astype(int)
        features["payee_velocity_1h"] = df["payee_velocity_1h"].astype(int)
        
        features["remote_access_detected"] = df["remote_access_detected"].astype(int)
        features["screen_sharing_active"] = df["screen_sharing_active"].astype(int)
        features["call_in_progress"] = df["call_in_progress"].astype(int)
        features["is_new_device"] = df["is_new_device"].astype(int)
        features["is_rooted"] = df["is_rooted"].astype(int)
        features["is_vpn"] = df["is_vpn"].astype(int)

        channels = df["channel"].str.upper()
        features["ch_collect"] = (channels == "COLLECT_REQUEST").astype(int)
        features["ch_static_qr"] = (channels == "STATIC_QR").astype(int)
        features["ch_dynamic_qr"] = (channels == "DYNAMIC_QR").astype(int)
        features["ch_intent"] = (channels == "INTENT").astype(int)
        features["ch_paylink"] = (channels == "PAYMENT_LINK").astype(int)
        features["ch_netbanking"] = (channels == "NETBANKING").astype(int)

        return features[FEATURE_COLUMNS]

    @classmethod
    def train_and_evaluate(cls, n_samples: int = 6000) -> Dict[str, Any]:
        """
        Trains the Random Forest Fraud Detection model on synthetic UPI transactions
        and calculates true offline evaluation metrics on hold-out test set.
        """
        os.makedirs(settings.ML_MODEL_DIR, exist_ok=True)
        print("Generating synthetic dataset for model training...")
        df = generate_synthetic_transactions(n_samples=n_samples)

        X = cls.extract_features_from_df(df)
        y = df["is_fraud"].values

        # 80/20 train/test split with stratification
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )

        print(f"Training ensemble model on {len(X_train)} samples...")
        clf = RandomForestClassifier(
            n_estimators=100,
            max_depth=12,
            min_samples_split=4,
            random_state=42,
            class_weight="balanced",
            n_jobs=-1
        )
        clf.fit(X_train, y_train)

        # Offline Evaluation on Test Set
        y_pred = clf.predict(X_test)
        y_proba = clf.predict_proba(X_test)[:, 1]

        acc = float(accuracy_score(y_test, y_pred))
        prec = float(precision_score(y_test, y_pred, zero_division=0))
        rec = float(recall_score(y_test, y_pred, zero_division=0))
        f1 = float(f1_score(y_test, y_pred, zero_division=0))
        roc = float(roc_auc_score(y_test, y_proba))
        
        cm = confusion_matrix(y_test, y_pred).tolist()
        tn, fp, fn, tp = cm[0][0], cm[0][1], cm[1][0], cm[1][1]
        
        # Fraud Detection Rate = Recall = TP / (TP + FN)
        fraud_detection_rate = float(tp / (tp + fn)) if (tp + fn) > 0 else 0.0
        # False Positive Rate = FP / (FP + TN)
        false_positive_rate = float(fp / (fp + tn)) if (fp + tn) > 0 else 0.0

        # Feature importances
        importances = {}
        for col, imp in zip(FEATURE_COLUMNS, clf.feature_importances_):
            importances[col] = round(float(imp), 4)

        # Sort feature importances descending
        sorted_importances = dict(sorted(importances.items(), key=lambda item: item[1], reverse=True))

        metrics = {
            "model_name": "PayRakshak-Ensemble-RF-v1.0",
            "train_samples": int(len(X_train)),
            "test_samples": int(len(X_test)),
            "accuracy": round(acc, 4),
            "precision": round(prec, 4),
            "recall": round(rec, 4),
            "f1_score": round(f1, 4),
            "roc_auc": round(roc, 4),
            "fraud_detection_rate": round(fraud_detection_rate, 4),
            "false_positive_rate": round(false_positive_rate, 4),
            "confusion_matrix": cm,  # [[TN, FP], [FN, TP]]
            "feature_importances": sorted_importances,
            "live_vs_offline_explanation": (
                "Offline evaluation metrics represent rigorous benchmark performance measured on the held-out test split "
                "of 1,200 labeled synthetic transactions (measuring algorithmic generalization, recall, and false-alarm rate). "
                "In contrast, Live Demo Statistics reflect real-time operational counts (total transactions processed, "
                "current queue alerts, and active blocked payments in the running demo instance)."
            )
        }

        # Save artifacts
        joblib.dump(clf, cls.get_model_path())
        joblib.dump(metrics, cls.get_metrics_path())

        cls._model = clf
        cls._metrics = metrics
        return metrics

    @classmethod
    def get_or_load_model(cls) -> Tuple[RandomForestClassifier, Dict[str, Any]]:
        if cls._model is not None and cls._metrics is not None:
            return cls._model, cls._metrics

        model_path = cls.get_model_path()
        metrics_path = cls.get_metrics_path()

        if os.path.exists(model_path) and os.path.exists(metrics_path):
            try:
                cls._model = joblib.load(model_path)
                cls._metrics = joblib.load(metrics_path)
                return cls._model, cls._metrics
            except Exception as e:
                print(f"Error loading model, retraining: {e}")

        # Train if not found
        metrics = cls.train_and_evaluate()
        return cls._model, metrics

    @classmethod
    def predict_request(cls, req: TransactionScanRequest, threat_vpas: set[str] = None) -> Dict[str, Any]:
        clf, _ = cls.get_or_load_model()
        
        # 1. Rule Engine evaluation
        rule_penalty, rule_hits, risk_factors, primary_cat, prevention_steps = RuleEngine.evaluate(
            req, threat_vpas=threat_vpas
        )

        # 2. Extract features for ML model
        dev = req.device_signals
        row = {
            "amount": float(req.amount),
            "log_amount": float(np.log1p(req.amount)),
            "hour": 14,  # Current default or extracted from time
            "payee_account_age_days": req.payee_account_age_days if req.payee_account_age_days is not None else 180,
            "payee_velocity_1h": req.payee_velocity_1h if req.payee_velocity_1h is not None else 1,
            "remote_access_detected": int(dev.remote_access_app_detected if dev else False),
            "screen_sharing_active": int(dev.screen_sharing_active if dev else False),
            "call_in_progress": int(dev.call_in_progress if dev else False),
            "is_new_device": int(dev.is_new_device if dev else False),
            "is_rooted": int(dev.is_rooted_or_jailbroken if dev else False),
            "is_vpn": int(dev.ip_vpn_or_proxy if dev else False),
            "channel": req.channel.upper(),
        }
        single_df = pd.DataFrame([row])
        X_features = cls.extract_features_from_df(single_df)

        # ML model prediction
        rf_prob = float(clf.predict_proba(X_features)[0][1])

        # Hybrid ensemble: combine RF probability (0-100) with expert rule penalties
        base_ml_score = rf_prob * 100.0
        combined_score = (base_ml_score * 0.5) + (rule_penalty * 0.5)

        # If any critical rule was triggered (e.g., AnyDesk active or PIN inversion collect scam), enforce floor
        has_critical_rule = any(r.severity == "CRITICAL" for r in rule_hits)
        if has_critical_rule:
            combined_score = max(combined_score, 82.0)

        # Cap score between 1 and 99
        final_risk_score = round(min(99.0, max(2.0, combined_score)), 1)

        # Determine Tier
        if final_risk_score >= 80.0:
            risk_tier = "CRITICAL"
            recommended_action = "BLOCK_TRANSACTION"
        elif final_risk_score >= 60.0:
            risk_tier = "HIGH"
            recommended_action = "CHALLENGE_PIN_COOLING"
        elif final_risk_score >= 35.0:
            risk_tier = "MODERATE"
            recommended_action = "WARN_USER_CONFIRM"
        elif final_risk_score >= 20.0:
            risk_tier = "LOW"
            recommended_action = "ALLOW_WITH_TAG"
        else:
            risk_tier = "SAFE"
            recommended_action = "ALLOW_TRANSACTION"

        is_flagged = final_risk_score >= 40.0
        final_category = primary_cat if is_flagged else "NORMAL"

        # Construct user-facing explanation summary
        if final_risk_score >= 80.0:
            explanation = (
                f"CRITICAL FRAUD ALERT (Risk Score: {final_risk_score}/100): "
                f"Suspicious activity matching '{final_category}'. High confidence indicator of social engineering deception. "
                "Transaction should be blocked to prevent irreversible fund loss."
            )
        elif final_risk_score >= 50.0:
            explanation = (
                f"ELEVATED RISK WARNING (Risk Score: {final_risk_score}/100): "
                f"Detected anomalous indicators in beneficiary velocity or channel configuration. "
                "Verify beneficiary identity before proceeding."
            )
        else:
            explanation = (
                f"VERIFIED SAFE (Risk Score: {final_risk_score}/100): "
                "Transaction signals conform to established legitimate UPI payment baselines. No malicious indicators found."
            )

        return {
            "risk_score": final_risk_score,
            "risk_tier": risk_tier,
            "scam_category": final_category,
            "is_flagged": is_flagged,
            "recommended_action": recommended_action,
            "explanation_summary": explanation,
            "risk_factors": [rf.model_dump() for rf in risk_factors],
            "rules_triggered": [rh.model_dump() for rh in rule_hits],
            "prevention_steps": prevention_steps,
            "device_signals": dev.model_dump() if dev else {},
            "ml_probability": round(rf_prob, 3),
            "rule_penalty": round(rule_penalty, 1)
        }

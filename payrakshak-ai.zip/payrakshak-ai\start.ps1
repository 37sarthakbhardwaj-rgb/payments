Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   PayRakshak AI — Startup Launcher" -ForegroundColor Cyan
Write-Host "   CCG-AI02: AI Detection of Creative Payment Frauds" -ForegroundColor Gray
Write-Host "==========================================================" -ForegroundColor Cyan

Write-Host "`n[1/2] Starting Backend in new window (http://localhost:8000)..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-ExecutionPolicy", "Bypass", "-File", "run_backend.ps1"

Start-Sleep -Seconds 3

Write-Host "[2/2] Starting Frontend in new window (http://localhost:5173)..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-ExecutionPolicy", "Bypass", "-File", "run_frontend.ps1"

Write-Host "`nPayRakshak AI is launching!" -ForegroundColor Green
Write-Host "Open your browser to: http://localhost:5173" -ForegroundColor Cyan
Write-Host "API Documentation:    http://localhost:8000/docs" -ForegroundColor Cyan
